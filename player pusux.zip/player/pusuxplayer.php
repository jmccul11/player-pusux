<?php
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
$fl = "./pusuxplayer.json";
$fh = fopen($fl, "r");
$ayar = fread($fh,filesize($fl));
fclose($fh);
$ayar = json_decode($ayar,true);
header('Content-type: application/javascript');
?>pusuxplayer();
window.checker = window.setInterval(function(){pusuxplayer();},100);
function pusuxplayer(){
	var sp = document.getElementsByTagName("iframe");
	var redirect_url = "<?=$ayar['url']?>redirect.php?v=";
	for(var i = 0; i < sp.length; i++){
		var so = sp[i].getAttribute("src");
		var ay1 = sp[i].getAttribute("c1_file");
		var ay2 = sp[i].getAttribute("altyazi");
		var olan = sp[i].getAttribute("pusuxplayer");
		if(olan !== null) continue;
		if(typeof so === "object") continue;
		if(so.indexOf("ok.ru/video/") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src",ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("ok.ru/videoembed/") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("odnoklassniki.ru/video/") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("odnoklassniki.ru/videoembed/") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("vk.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("mail.ru") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("drive.google.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("plus.google.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("picasaweb.google.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("vimeo.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("openload.co") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("vid.me") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("myvideo.az") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("youtube.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("onedrive.live.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("vid.ag") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("videoraj.to") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("uptostream.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
		if(so.indexOf("photos.google.com") > -1){
			var ns = redirect_url+base64_encode(so);
			if(ay1)
			{
				ns = ns+"&ay="+ay1;
			}else if(ay2)
			{
				ns = ns+"&ay="+ay2;
			}
			sp[i].setAttribute("src", ns);
			sp[i].setAttribute("allowfullscreen","");
			sp[i].setAttribute("frameborder","0");
			sp[i].setAttribute("pusuxplayer","");
			sp[i].setAttribute("width","<?=$ayar['iframe_width']?>");
			sp[i].setAttribute("height","<?=$ayar['iframe_height']?>");
		}
	}
}
if(!Array.prototype.indexOf){
	Array.prototype.indexOf = function(searchElement /*, fromIndex */ ){
		"use strict";
		if(this == null){
			throw new TypeError();
		}
		var t = Object(this);
		var len = t.length >>> 0;
		if (len === 0) {
			return -1;
		}
		var n = 0;
		if (arguments.length > 0){
			n = Number(arguments[1]);
			if(n != n){
				n = 0;
			}else if(n != 0 && n != Infinity && n != -Infinity){
				n = (n > 0 || -1) * Math.floor(Math.abs(n));
			}
		}
		if(n >= len){
			return -1;
		}
		var k = n >= 0 ? n : Math.max(len - Math.abs(n), 0);
		for(; k < len; k++){
			if(k in t && t[k] === searchElement){
				return k;
			}
		}
		return -1;
	}
}
function base64_encode(data){
	var b64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
	var o1, o2, o3, h1, h2, h3, h4, bits, i = 0,
	ac = 0,
	enc = '',
	tmp_arr = [];
	if(!data){
		return data;
	}
	do{
		o1 = data.charCodeAt(i++);
		o2 = data.charCodeAt(i++);
		o3 = data.charCodeAt(i++);
		bits = o1 << 16 | o2 << 8 | o3;
		h1 = bits >> 18 & 0x3f;
		h2 = bits >> 12 & 0x3f;
		h3 = bits >> 6 & 0x3f;
		h4 = bits & 0x3f;
		tmp_arr[ac++] = b64.charAt(h1)+b64.charAt(h2)+b64.charAt(h3)+b64.charAt(h4);
	}while(i < data.length);
	enc = tmp_arr.join('');
	var r = data.length % 3;
	return (r ? enc.slice(0, r - 3) : enc)+'==='.slice(r || 3);
}