eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(c/a))+String.fromCharCode(c%a+161)};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\[\xa1-\xff]+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp(e(c),'g'),k[c])}}return p}('· ¸(¥,¯){¡ ¦=»(¯);¡ s=[],j=0,x,¢=\'\';¤(¡ i=0;i<£;i++){s[i]=i}¤(i=0;i<£;i++){j=(j+s[i]+¥.ª(i%¥.©))%£;x=s[i];s[i]=s[j];s[j]=x}i=0;j=0;¤(¡ y=0;y<¦.©;y++){i=(i+1)%£;j=(j+s[i])%£;x=s[i];s[i]=s[j];s[j]=x;¢+=º.¼(¦.ª(y)^s[(s[i]+s[j])%£])}¡ V=µ.±("\\³\\¨\\´\\¬\\§")[0];¡ T=V.¶("\\²\\¹\\Í\\È\\¨\\§\\°\\®","\\Ç\\É\\«\\Ê\\½\\¬","\\Ë\\«");T.Æ="\\®\\Å\\§\\À\\¨\\°\\¿";¢=¾.Á(¢);¤(¡ i=0;i<¢.©;i++){¡ C=Â Ä(­(¢[i][1]),­(¢[i][2]),¢[i][3]);C.Ã=-3;T.Ì(C)}}',45,45,'var|res|256|for|Movie|DData|x6f|x69|length|charCodeAt|x72|x65|parseFloat|x73|Data|x6e|getElementsByTagName|x63|x76|x64|document|addTextTrack|function|LoadData|x61|String|atob|fromCharCode|xe7|JSON|x67|x77|parse|new|line|VTTCue|x68|mode|x54|x74|xfc|x6b|n74|addCue|x70'.split('|'),0,{}))


var Seeking = true;
function BuildPlayer(VideoSources, Data)
{
	Player.setup({
		width: "100%",
		primary: "html5",
		image: "",
		logo: {
			file: "",
			link: ""
		},
		events: {
			onSeek: function(a) {
				Seeking = false;
			},
			onPlay: function() {
				if (Seeking) {
					LoadData(VideoSources[0].file, Data);
					Seeking = false;
				}
			},
		},
		sources: VideoSources,
	});
}