<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
require( dirname( __FILE__ ) . '/inc/setting.php' );
/*koruma modu*/
if($ayar["hotlink_status"]=="1" and hotlink_check($ayar["hotlink_domain"])==false)
{
	go_redirect($ayar["hotlink_redirect"]);
}
/*get verilerini alalım*/
$data = get_data();
$subtitle = get_subtitle();
if($data!="" and !empty($data["type"])){
	/*klasik get data*/
	$type = $data["type"];
	if($type=="classic"){
		$data = px_classic_data($data);
		$data["subtitle"] = $subtitle;
	}elseif($type=="md5"){
		$data = px_md5_data($data);
	}
	/*sınıf çalıştırma ve şablonu yazdırma*/
	//print_R($data);
	/*picasa*/
	if($data["platform"]=="picasa")
	{
		$picasa = new platform_picasa($ayar);
		$picasa->type = $type;
		$picasa->url_data = $data["data"];
		$picasa->url_platform = $data["platform"];
		$picasa->subtitle = $data["subtitle"];
		$picasa->type_id = $data["id"];
		$data = $picasa->get_data();
	}
	/*plus*/
	elseif($data["platform"]=="plus")
	{
		$plus = new platform_plus($ayar);
		$plus->type = $type;
		$plus->url_data = $data["data"];
		$plus->url_platform = $data["platform"];
		$plus->subtitle = $data["subtitle"];
		$plus->type_id = $data["id"];
		$data = $plus->get_data();
	}
	/*drive*/
	elseif($data["platform"]=="drive")
	{
		$drive = new platform_drive($ayar);
		$drive->type = $type;
		$drive->url_data = $data["data"];
		$drive->url_platform = $data["platform"];
		$drive->subtitle = $data["subtitle"];
		$drive->type_id = $data["id"];
		$data = $drive->get_data();
	}
	/*ok.ru*/
	elseif($data["platform"]=="ok")
	{
		$okru = new platform_ok($ayar);
		$okru->type = $type;
		$okru->url_data = $data["data"];
		$okru->url_platform = $data["platform"];
		$okru->subtitle = $data["subtitle"];
		$okru->type_id = $data["id"];
		$data = $okru->get_data();
	}
	/*vimeo*/
	elseif($data["platform"]=="vimeo")
	{
		$vimeo = new platform_vimeo($ayar);
		$vimeo->type = $type;
		$vimeo->url_data = $data["data"];
		$vimeo->url_platform = $data["platform"];
		$vimeo->subtitle = $data["subtitle"];
		$vimeo->type_id = $data["id"];
		$data = $vimeo->get_data();
	}
	/*openload*/
	elseif($data["platform"]=="openload")
	{
		//require( dirname( __FILE__ ) . '/inc/AADecoder/AADecoder.php' );
		$openload = new platform_openload($ayar);
		$openload->type = $type;
		$openload->url_data = $data["data"];
		$openload->url_platform = $data["platform"];
		$openload->subtitle = $data["subtitle"];
		$openload->type_id = $data["id"];
		$data = $openload->get_data();
	}
	/*vid.me*/
	elseif($data["platform"]=="vidme")
	{
		$vidme = new platform_vidme($ayar);
		$vidme->type = $type;
		$vidme->url_data = $data["data"];
		$vidme->url_platform = $data["platform"];
		$vidme->subtitle = $data["subtitle"];
		$vidme->type_id = $data["id"];
		$data = $vidme->get_data();
	}
	/*myvideo.az*/
	elseif($data["platform"]=="myvideo")
	{
		$myvideo = new platform_myvideo($ayar);
		$myvideo->type = $type;
		$myvideo->url_data = $data["data"];
		$myvideo->url_platform = $data["platform"];
		$myvideo->subtitle = $data["subtitle"];
		$myvideo->type_id = $data["id"];
		$data = $myvideo->get_data();
	}
	/*youtube*/
	elseif($data["platform"]=="youtube")
	{
		//require( dirname( __FILE__ ) . '/inc/youtube_sig/youtube_sig.class.php' );
		$youtube = new platform_youtube($ayar);
		$youtube->type = $type;
		$youtube->url_data = $data["data"];
		$youtube->url_platform = $data["platform"];
		$youtube->subtitle = $data["subtitle"];
		$youtube->type_id = $data["id"];
		$data = $youtube->get_data();
	}
	/*onedrive.live.com*/
	elseif($data["platform"]=="onedrivelive")
	{
		$onedrivelive = new platform_onedrivelive($ayar);
		$onedrivelive->type = $type;
		$onedrivelive->url_data = $data["data"];
		$onedrivelive->url_platform = $data["platform"];
		$onedrivelive->subtitle = $data["subtitle"];
		$onedrivelive->type_id = $data["id"];
		$data = $onedrivelive->get_data();
	}
	/*mail.ru*/
	elseif($data["platform"]=="mail")
	{
		$mail = new platform_mail($ayar);
		$mail->type = $type;
		$mail->url_data = $data["data"];
		$mail->url_platform = $data["platform"];
		$mail->subtitle = $data["subtitle"];
		$mail->type_id = $data["id"];
		$data = $mail->get_data();
	}
	/*vk.com*/
	elseif($data["platform"]=="vk")
	{
		$vk = new platform_vk($ayar);
		$vk->type = $type;
		$vk->url_data = $data["data"];
		$vk->url_platform = $data["platform"];
		$vk->subtitle = $data["subtitle"];
		$vk->type_id = $data["id"];
		$data = $vk->get_data();
	}
	/*vid.ag*/
	elseif($data["platform"]=="vidag")
	{
		$vidag = new platform_vidag($ayar);
		$vidag->type = $type;
		$vidag->url_data = $data["data"];
		$vidag->url_platform = $data["platform"];
		$vidag->subtitle = $data["subtitle"];
		$vidag->type_id = $data["id"];
		$data = $vidag->get_data();
	}
	/*videoraj.to*/
	elseif($data["platform"]=="videoraj")
	{
		$videoraj = new platform_videoraj($ayar);
		$videoraj->type = $type;
		$videoraj->url_data = $data["data"];
		$videoraj->url_platform = $data["platform"];
		$videoraj->subtitle = $data["subtitle"];
		$videoraj->type_id = $data["id"];
		$data = $videoraj->get_data();
	}
	/*uptostream*/
	elseif($data["platform"]=="uptostream")
	{
		$uptostream = new platform_uptostream($ayar);
		$uptostream->type = $type;
		$uptostream->url_data = $data["data"];
		$uptostream->url_platform = $data["platform"];
		$uptostream->subtitle = $data["subtitle"];
		$uptostream->type_id = $data["id"];
		$data = $uptostream->get_data();
	}
	/*mp4 */
	elseif($data["platform"]=="mp4")
	{
		$mp4stream = new platform_mp4stream($ayar);
		$mp4stream->type = $type;
		$mp4stream->url_data = $data["data"];
		$mp4stream->url_platform = $data["platform"];
		$mp4stream->subtitle = $data["subtitle"];
		$mp4stream->type_id = $data["id"];
		$data = $mp4stream->get_data();
	}
	/*facebook */
	elseif($data["platform"]=="facebook")
	{
		$facebook = new platform_facebook($ayar);
		$facebook->type = $type;
		$facebook->url_data = $data["data"];
		$facebook->url_platform = $data["platform"];
		$facebook->subtitle = $data["subtitle"];
		$facebook->type_id = $data["id"];
		$data = $facebook->get_data();
	}
	/*google photos */
	elseif($data["platform"]=="photos")
	{
		$photos = new platform_photos($ayar);
		$photos->type = $type;
		$photos->url_data = $data["data"];
		$photos->url_platform = $data["platform"];
		$photos->subtitle = $data["subtitle"];
		$photos->type_id = $data["id"];
		$data = $photos->get_data();
	}
	/*get verileri geçersiz ise*/
	elseif($data["platform"]=="404")
	{
		$data["template"] = "error";
	}else
	{
		$data["template"] = "error";
	}
	//print_R($data);exit;
	get_template($data);
}
?>