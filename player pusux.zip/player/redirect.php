<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
require("./inc/functions.php");
$fl = "./pusuxplayer.json";
$fh = fopen($fl, "r");
$ayar = fread($fh,filesize($fl));
fclose($fh);
$ayar = json_decode($ayar,true);
/*koruma modu*/
if($ayar["hotlink_status"]=="1" and hotlink_check($ayar["hotlink_domain"])==false)
{
	go_redirect($ayar["hotlink_redirect"]);
}
/*işlemler*/
require("./inc/platform_generate_data/platform_generate_data.php");
if(isset($_GET['v']) and !empty($_GET['v']))
{
	if(isset($_GET['ay']) and !empty($_GET['ay']))
	{
		$subtitle = "&subtitle=".urlencode($_GET['ay']);
	}else $subtitle = "";
	$url = base64_decode($_GET['v']);
	$platform_data = new platform_generate_data();
	$data = $platform_data->get_data($url,false);
	if(count($data)>1)
	{
		$data = implode("/",$data);
		$data = px_encode($data);
		$url = $ayar["url"]."url/".$data.$subtitle;
	}
	go_redirect($url);
}
?>