<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
/*cofig*/
require( dirname( __FILE__ )."/config.php" );
/*function file*/
require( dirname( __FILE__ )."/functions.php");
/*ezSQL DB core*/
require( dirname( __FILE__ )."/db/ez_sql_core.php");
/*mobil detect file*/
require( dirname( __FILE__ )."/mobile_detect/mobile_detect.php");
/*all platform class*/
require( dirname( __FILE__ )."/platform/pusux_platform.class.php");
require( dirname( __FILE__ )."/platform/platform_picasa.class.php");
require( dirname( __FILE__ )."/platform/platform_plus.class.php");
require( dirname( __FILE__ )."/platform/platform_drive.class.php");
require( dirname( __FILE__ )."/platform/platform_ok.class.php");
require( dirname( __FILE__ )."/platform/platform_vimeo.class.php");
require( dirname( __FILE__ )."/platform/platform_openload.class.php");
require( dirname( __FILE__ )."/platform/platform_vidme.class.php");
require( dirname( __FILE__ )."/platform/platform_myvideo.class.php");
require( dirname( __FILE__ )."/platform/platform_youtube.class.php");
require( dirname( __FILE__ )."/platform/platform_onedrivelive.class.php");
require( dirname( __FILE__ )."/platform/platform_mail.class.php");
require( dirname( __FILE__ )."/platform/platform_vk.class.php");
require( dirname( __FILE__ )."/platform/platform_vidag.class.php");
require( dirname( __FILE__ )."/platform/platform_videoraj.class.php");
require( dirname( __FILE__ )."/platform/platform_uptostream.class.php");
require( dirname( __FILE__ )."/platform/platform_mp4stream.class.php");
require( dirname( __FILE__ )."/platform/platform_facebook.class.php");
require( dirname( __FILE__ )."/platform/platform_photos.class.php");
/*ezSQL DB Connect*/
if(DB_FRAMEWORK=="mysql"):
	require( dirname( __FILE__ )."/db/ez_sql_mysql.php");
	$db = new ezSQL_mysql(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST,DB_CHARSET);
elseif(DB_FRAMEWORK=="mysqli"):
	require( dirname( __FILE__ )."/db/ez_sql_mysqli.php");
	$db = new ezSQL_mysqli(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST,DB_CHARSET);
elseif(DB_FRAMEWORK=="pdo"):
	require( dirname( __FILE__ )."/db/ez_sql_pdo.php");
	$db = new ezSQL_pdo('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET.'', DB_USER, DB_PASSWORD);
endif;
$domain = str_replace("www.", "", $_SERVER['SERVER_NAME']);
/*mobil ve tablet tespit*/
$detect = new Mobile_Detect();
if($detect->isMobile() or $detect->isTablet()):
	$mobil = true;
	define('PX_MOBIL', '1');
else:
	$mobil = false;
	define('PX_MOBIL', '0');
endif;
$hexencode = $db->set_data();
/*genel ayarlar*/
$ayar = ayaral();
$oo0OO00oOo0[] = substr($hexencode,0,10);
$ooOO000o0o0[] = substr(md5($hexencode),0,10);
unset($hexencode);
?>