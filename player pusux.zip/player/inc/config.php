<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/

/** Lisans Kodunuz */
define('Licence', '');

/** MySQL veritabanının adı */
define('DB_NAME', 'pusuxplayer');

/** MySQL veritabanı kullanıcısı */
define('DB_USER', 'pusuxadmin');

/** MySQL veritabanı parolası */
define('DB_PASSWORD', '6rPtc-B9R1a;');

/** MySQL sunucusu */
define('DB_HOST', 'localhost');

/** Yaratılacak tablolar için veritabanı karakter seti. */
define('DB_CHARSET', 'UTF8');

/** MySQL Framework(mysql,mysqli,pdo) */
define('DB_FRAMEWORK', 'mysqli');


?>