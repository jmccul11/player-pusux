<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_generate_data{
	public function get_data($url,$mp4=false)
	{
		$data = $this->platform_detect($url,$mp4);
		return $data;
	}
	private function platform_detect($url,$mp4)
	{
		if($mp4==true)
			$data = $this->mp4stream($url);
		elseif(preg_match('@picasaweb\.google@si',$url))
			$data = $this->g_picasa($url);
		elseif(preg_match('@plus\.google@si',$url))
			$data = $this->g_plus($url);
		elseif(preg_match('@drive\.google@si',$url))
			$data = $this->g_drive($url);
		elseif(preg_match('@ok\.ru|odnoklassniki.ru@si',$url))
			$data = $this->okru($url);
		elseif(preg_match('@vimeo\.com@si',$url))
			$data = $this->vimeo($url);
		elseif(preg_match('@openload\.co@si',$url))
			$data = $this->openload($url);
		elseif(preg_match('@vid\.me@si',$url))
			$data = $this->vidme($url);
		elseif(preg_match('@myvideo\.az@si',$url))
			$data = $this->myvideo($url);
		elseif(preg_match('@youtu\.be|youtube\.com@si',$url))
			$data = $this->g_youtube($url);
		elseif(preg_match('@onedrive\.live\.com@si',$url))
			$data = $this->onedrivelive($url);
		elseif(preg_match('@mail\.ru@si',$url))
			$data = $this->mailru($url);
		elseif(preg_match('@vk\.com@si',$url))
			$data = $this->vkcom($url);
		elseif(preg_match('@vid\.ag@si',$url))
			$data = $this->vidag($url);
		elseif(preg_match('@videoraj\.to@si',$url))
			$data = $this->videoraj($url);
		elseif(preg_match('@uptostream\.com@si',$url))
			$data = $this->uptostream($url);
		elseif(preg_match('@facebook\.com@si',$url))
			$data = $this->facebook($url);
		elseif(preg_match('@photos\.google\.com@si',$url))
			$data = $this->photos($url);
		else 
			$data = array();
		return $data;
	}
	private function mp4stream($url)
	{
		$vid = array();
		$url = urlencode($url);
		$vid[0] = "mp4";
		$vid[1] = $url;
		return $vid;
	}
	private function photos($url)
	{
		$vid = array();
		$vid[0] = "photos";
		if(preg_match('@/share/(.*?)/photo/@si',$url))
		{
			$p = explode("/share/",$url);
			$p = explode("/photo/",$p[1]);
			$vid[1] = $p[0];
			$p = explode("?",$p[1]);
			$vid[2] = $p[0];
			if(preg_match('@\?key=@si',$url))
			{
				$parts = parse_url(urldecode($url)); 
				parse_str($parts['query'], $query);
				$key = $query['key'];
				$vid[3] = $key;
			}
		}
		return $vid;
	}
	private function facebook($url)
	{
		$vid = array();
		if(preg_match('@video\.php\?v=@si',$url))
		{
			$parts = parse_url(urldecode($url));
			parse_str($parts['query'], $query);
			$p = $query['v'];
		}elseif(preg_match('@/videos/vb\.@si',$url)){
			$e = explode("/videos/vb.",$url);
			$e = explode("/",$e[1]);
			$p = $e[1];
			$pid = $e[0];
		}elseif(preg_match('@/videos/@si',$url)){
			preg_match('@com/(.*?)/videos/(.*?)/@si',$url."/",$e);
			$p = $e[2];
			$pid = $e[1];
		}
		if(!isset($p) or empty($p))
			return array();
		$vid[0] = "facebook";
		$vid[1] = $p;
		if(isset($pid))
			$vid[2] = $pid;
		return $vid;
	}
	private function uptostream($url)
	{
		$vid = array();
		$p = explode("iframe/",$url);
		$p = explode("?",$p[1]);
		$p = explode("/",$p[0]);
		if(!isset($p[0]) or empty($p[0]))
			return array();
		$vid[0] = "uptostream";
		$vid[1] = $p[0];
		return $vid;
	}
	private function videoraj($url)
	{
		$vid = array();
		$parts = parse_url(urldecode($url));
		parse_str($parts['query'], $query);
		if(!isset($query['id']) or empty($query['id']))
			return array();
		$vid[0] = "videoraj";
		$vid[1] = $query['id'];
		return $vid;
	}
	private function vidag($url)
	{
		$vid = array();
		preg_match('@embed-(.*?)\.html@si',$url,$id);
		if(!isset($id[1]) or empty($id[1]))
		{
			preg_match('@\.ag/(.*?)\.html@si',$url,$id);
		}
		$vid[0] = "vidag";
		$vid[1] = $id[1];
		return $vid;
	}
	private function vkcom($url)
	{
		$vid = array();
		$parts = parse_url(urldecode($url));
		parse_str($parts['query'], $query);
		$vid[0] = "vk";
		$vid[1] = $query['oid'];
		$vid[2] = $query['id'];
		$vid[3] = $query['hash'];
		return $vid;
	}
	private function mailru($url)
	{
		$sb = explode("/",$url);
		$sl = count($sb)-1;
		$sl = explode(".html",$sb[$sl]);
		$id = (int)$sl[0];
		if(preg_match('@/bk/@si',$url))
		{
			preg_match('@/bk/(.*?)/@si',$url,$kadi);
			$type = "bk";
			
		}elseif(preg_match('@/inbox/@si',$url))
		{
			preg_match('@/inbox/(.*?)/@si',$url,$kadi);
			$type = "inbox";
			
		}elseif(preg_match('@/v/@si',$url))
		{
			preg_match('@/v/(.*?)/@si',$url,$kadi);
			$type = "v";
			
		}elseif(preg_match('@/mail/@si',$url))
		{
			preg_match('@/mail/(.*?)/@si',$url,$kadi);
			$type = "mail";
		}
		$vid = array();
		$vid[0] = "mail";
		$vid[1] = $kadi[1];
		$vid[2] = $id;
		$vid[3] = $type;
		
		return $vid;
	}
	private function onedrivelive($url)
	{
		$vid = array();
		$parts = parse_url(urldecode($url)); 
		parse_str($parts['query'], $query);
		if(!isset($query["resid"]) or empty($query["resid"]))
			return array();
		$key = $query['authkey'];
		$vid[0] = "onedrivelive";
		$vid[1] = $query["resid"];
		$vid[2] = $query["authkey"];
		return $vid;
	}
	private function g_youtube($url)
	{
		$vid = array();
		preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $url, $matches);
		if(!isset($matches[1]) or empty($matches[1]))
			return array();
		$vid[0] = "youtube";
		$vid[1] = $matches[1];
		return $vid;
	}
	private function myvideo($url)
	{
		$vid = array();
		if(preg_match('@video_id=@si',$url))
		{
			$p = explode("video_id=",$url);
			$p = preg_split('@\.|\?@si',$p[1]);
		}else{
			$p = explode("/v/",$url);
			$p = preg_split('@\.|\?@si',$p[1]);
		}
		if(!isset($p[0]) or empty($p[0]))
			return array();
		$vid[0] = "myvideo";
		$vid[1] = $p[0];
		return $vid;
	}
	private function vidme($url)
	{
		$vid = array();
		$p = explode("me/",$url);
		$p = explode("/",$p[1]);
		if(isset($p[1]))
		{
			$p = explode("?",$p[1]);
		}else{
			$p = explode("?",$p[0]);
		}
		if(!isset($p[0]) or empty($p[0]))
			return array();
		$vid[0] = "vidme";
		$vid[1] = $p[0];
		return $vid;
	}
	private function openload($url)
	{
		$vid = array();
		preg_match('@/embed/(.*?)/@si',$url."/",$p);  
		if(!isset($p[1]) or empty($p[1]))
			return array();
		$vid[0] = "openload";
		$vid[1] = $p[1];
		return $vid;
	}
	private function vimeo($url)
	{
		$vid = array();
		if(preg_match("@/video/@si",$url)) {
			$p = explode("/video/",$url);
			$p = explode("?",$p[1]);
			$vid[0] = "vimeo";
			$vid[1] = (int)$p[0];
		}else{
			$p = explode("com/",$url);
			$vid[0] = "vimeo";
			$vid[1] = (int)$p[1];
		}
		return $vid;
	}
	private function okru($url)
	{
		$vid = array();
		if(preg_match('@videoembed@si',$url))
		{
			$p = explode("videoembed/",$url);
		}else{
			$p = explode("video/",$url);
		}
		if(!isset($p[1]) or empty($p[1]))
			return array();
		$vid[0] = "ok";
		$vid[1] = $p[1];
		return $vid;
	}
	private function g_drive($url)
	{
		$vid = array();
		$url = $url."/";
		preg_match('@/file/.*?/(.*?)/@si',$url,$p);
		if(!isset($p[1]) or empty($p[1]))
			return array();
		$vid[0] = "drive";
		$vid[1] = $p[1];
		return $vid;
	}
	private function g_plus($url)
	{
		$vid = array();
		if(preg_match('@/albums/@si',$url))
		{
			$url = explode("?",$url);
			preg_match('@/photos/(.*?)/albums/(.*?)/(.*?)/@si',$url[0]."/",$p);
			$vid[0] = "plus";
			$vid[1] = $p[1];
			$vid[2] = $p[2];
			$vid[3] = $p[3];
		}elseif(preg_match('@/posts/@si',$url))
		{
			$parts = parse_url($url);
			parse_str($parts['query'], $query);
			if(isset($query['pid']) and isset($query['oid']))
			{
				$vid[0] = "plus";
				$vid[1] = $query['oid'];
				$vid[2] = $query['pid'];
			}else{
				preg_match('@com/(.*?)/posts/.*?\?pid=(.*?)&@si',$url,$p);
				$vid[0] = "plus";
				$vid[1] = $p[1];
				$vid[2] = $p[2];
			}
		}
		return $vid;
	}
	private function g_picasa($url)
	{
		$exec = $this->get_curl($url);
		//return $exec;
		if(preg_match('@authkey=@si',$url,$key))
		{
			$parts = parse_url(urldecode($url)); 
			parse_str($parts['query'], $query);
			$key = $query['authkey'];
		}else $key = "";
		//print_r($exec);exit;
		preg_match('@"faceProcessing".*?"id":"https://picasaweb.google.com/data/entry/user/(.*?)/albumid/(.*?)/photoid/(.*?)"@si',$exec,$p);
		if(@$p[1] and @$p[2])
		{
			//echo $url;
			$url2 = explode("/".$p[1]."/",$url);
			$url = explode("?",$url2[1]);
			$url = explode("#",$url[0]);
			//print_r($url);
			if(isset($url[1]))
				$p[3] = $url[1];
			else{
				$urlsh = explode("#",$url2[1]);
				if(isset($urlsh[1]))
					$p[3] = $urlsh[1];
			}
			$vid = array();
			$vid[0] = "picasa";
			$vid[1] = $p[1];
			$vid[2] = $p[2];
			$vid[3] = $p[3];
			$vid[4] = $url[0];
			if($key!="")
				$vid[5] = $key;
		}else $vid = array();
		//print_r($vid);exit;
		return $vid;
	}
	private function get_curl($link,$https=true,$ipresolve6=false)
	{
		if (function_exists('curl_init')) {
		$useragent =  'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36';
		$c = curl_init();
		curl_setopt($c, CURLOPT_BINARYTRANSFER, 1);
		curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($c, CURLOPT_URL, $link);
		curl_setopt($c, CURLOPT_AUTOREFERER, 1);
		curl_setopt($c, CURLOPT_REFERER, $link);
		curl_setopt($c, CURLOPT_TIMEOUT, 20);
		curl_setopt($c, CURLOPT_USERAGENT, $useragent);
		@curl_setopt($c, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
		if($ipresolve6==true)
		{
			@curl_setopt($c, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V6 );
		}
		if($https==true)
		{
			curl_setopt($c, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
		}
		return curl_exec($c);
		} else {
			return file_get_contents($link);
		}
	}
}
?>