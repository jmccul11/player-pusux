<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
##############################################
//##genel ayarlar
##############################################
function ayaral()
{
	global $db;
	$rows = $db->get_results("select * from ayarlar");
	foreach ( $rows as $row )
	{
		$ayar[$row->bolum] = $row->deger;
	}
	return $ayar;
}
##############################################
//##get ile almamız gereken tüm değişkenler
##############################################
function isValidMd5($md5){
	return strlen($md5) == 32 && ctype_xdigit($md5);
}
function get_data()
{
	global $db;
	//get verisi al
	if(isset($_GET['v']))
		$get_data = $db->escape($_GET['v']);
	elseif(isset($_GET['i']))
		$get_data = $db->escape($_GET['i']);
	else $get_data = "";
	//veri yok yada boşsa boş döndür
	if(empty($get_data))
		return "";
	//veri tipi seç
	$data = array();
	if(isValidMd5($get_data))
	{
		$data["type"] = "md5";
		$data["get_id"] = "i";
	}else{
		$data["type"] = "classic";
		$data["get_id"] = "v";
	}
	$data["data"] = $get_data;
	return $data;
}
function get_subtitle()
{
	global $db;
	//pusux klasik için
	if(isset($_GET['ay']) and !empty($_GET['ay']))
	{
		$data = $db->escape($_GET['ay']);
	}elseif(isset($_GET['subtitle']) and !empty($_GET['subtitle']))
	{
		$data = $db->escape($_GET['subtitle']);
	}else{
		$data = "";
	}
	$data = urldecode($data);
	return $data;
}
$hex = array();
function get_playermode()
{
	global $db;
	//pusux klasik için
	if(isset($_GET['mode']) and !empty($_GET['mode']))
	{
		if($_GET['mode']=="html5") $data = "html5";
		elseif($_GET['mode']=="flash") $data = "flash";
		else $data = "";
	}else{
		$data = "";
	}
	$data = urldecode($data);
	return $data;
}
##############################################
//##pusux klasik decoding ve encoding
##############################################
function px_encode($id)
{
	$base = base64_encode($id);
	$ret = strrev($base);
	$ret = base64_encode($ret);
	return $ret;
}
function px_decode($id)
{
	global $oo0OO00oOo0;
//	if($oo0OO00oOo0[0]!=$oo0OO00oOo0[1]) exit("_");
	$base = base64_decode($id);
	$base = strrev($base);
	$ret = base64_decode($base);
	return $ret;
}
##############################################
//##pusux klasik medya tespit
##############################################
function px_classic_data($id)
{
	$id = px_decode($id["data"]);
	$id = explode("/",$id);
	$data["id"] = "";
	$data["platform"] = $id[0];
	$data["data"] = $id;
	return $data;
}

##############################################
//##pusux md5 medya tespit
##############################################
function px_md5_data($id)
{
	global $db;
	$code = $id["data"];
	$row = $db->get_row("select * from movie where code='$code'");
	if($row)
	{
		$sid = unserialize($row->url_data);
		$data["id"] = $row->id;
		$data["platform"] = $row->platform;
		$data["data"] = $sid;
		$data["subtitle"] = $row->subtitle;
	}else{
		$data["platform"] = "404";
	}
	
	return $data;
}
##############################################
//##template getir
##############################################
function get_template($data)
{
	global $ayar,$ooOO000o0o0;
	//if($ooOO000o0o0[0]!=$ooOO000o0o0[1]) exit("_");
	$name = $data["template"];
	require( get_home_directory() . '/template/'.$name.'/index.php' );
}
##############################################
//##script ana dizini getir
##############################################
function get_home_directory()
{
	$dz = dirname( __FILE__ );
	$dz = explode("inc",$dz);
	return $dz[0];
}
##############################################
//##script ana sayfa url
##############################################
function get_home_url(){
	global $ayar;
	return $ayar["url"];
}
##############################################
//##plyer modu alma
##############################################
function get_player_mode($data){
	global $mobil;
	if($mobil==true)
	{
		$mode = $data->jwdata;
		return $mode["jw_mobile_mode"];
	}else{
		global $ooOO000o0o0;
		//if($ooOO000o0o0[0]!=$ooOO000o0o0[1]) exit("_");
		if(get_playermode()=="")
			return $data->mode;
		else 
			return get_playermode();
	}
}
##############################################
//##player modu butonu
##############################################
function player_mode_button($data)
{
	global $mobil,$ayar;
	$button = unserialize($ayar["jw_button"]);
	if($mobil==false and $button["mode"]==1)
	{
		$id = get_data();
		if($id["type"]=="classic"){
			$url = get_home_url().'url/'.$id['data'].'?mode=';
		}elseif($id["type"]=="md5"){
			$url = get_home_url().'url/'.$id['data'].'&mode=';
		}
		
		if(get_subtitle()!="")
		{
			$ay = "&ay=".urlencode(get_subtitle());
		}else{
			$ay = "";
		}
		if(get_playermode()!="")
			$data->mode = get_playermode();
		
		if($data->mode=="flash")
		{
			echo '<a title="Şuanda Flash Player Kullanıyorsunuz. Html5 Player kullanmak için tıklayın!" href="'.$url.'html5'.$ay.'"><img src="'.get_home_url().'img/html5.png"/></a>';
		}elseif($data->mode=="html5"){
			echo '<a title="Şuanda Html5 Player Kullanıyorsunuz. Flash Player kullanmak için tıklayın!" href="'.$url.'flash'.$ay.'"><img src="'.get_home_url().'img/flash.png"/></a>';
		}
	}
	return "";
}
##############################################
//##player download butonu
##############################################
function player_download_button($stream)
{
	global $ayar;
	$button = unserialize($ayar["jw_button"]);
	if($button["download"]==1)
	{
	?>
	<div>
		<div id="down">
			<img src="<?=get_home_url()?>/img/download.png">
			<ul class="down-list">
			<?php foreach($stream as $player): ?>
				<li><a href="<?=preg_replace('@"@si','%22',$player['kalip'])?>" download><?=$player['tur']?></a></li>
			<?php endforeach; ?>
			</ul>
		</div>
	</div>
	<?php
	}
}
##############################################
//##yönlendirme fonksiyonu(aynısı pusux platform sınıfındada var)
##############################################
function go_redirect($url, $time = 0){
	if($time): 
		@header("Refresh: {$time}; url={$url}");
		echo '
		<!DOCTYPE HTML>
		<html lang="en-US">
			<head>
				<meta charset="UTF-8">
				<meta http-equiv="refresh" content="'.$time.';url='.$url.'">
				<script type="text/javascript">
					window.location.href = "'.$url.'"
				</script>
				<title>Page Redirection</title>
			</head>
			<body>
				<!-- Note: don\'t tell people to `click` the link, just tell them that it is a link. -->
				If you are not redirected automatically, follow the <a href=\''.$url.'\'>link to example</a>
			</body>
		</html>
		';
	else:
		@header("Location: {$url}");
		echo '
		<!DOCTYPE HTML>
		<html lang="en-US">
			<head>
				<meta charset="UTF-8">
				<meta http-equiv="refresh" content="'.$time.';url='.$url.'">
				<script type="text/javascript">
					window.location.href = "'.$url.'"
				</script>
				<title>Page Redirection</title>
			</head>
			<body>
				<!-- Note: don\'t tell people to `click` the link, just tell them that it is a link. -->
				If you are not redirected automatically, follow the <a href=\''.$url.'\'>link to example</a>
			</body>
		</html>
		';
	endif;
	exit();
}
##############################################
//##
##############################################
function update_option($colm,$data)
{
	global $db;
	$db->query("UPDATE ayarlar SET deger='$data' where bolum='$colm'");
}
##############################################
//##referer domain
##############################################
function getReferer(){ 
	preg_match('@^(?:http://)?([^/]+)@i',@$_SERVER['HTTP_REFERER'], $match); 
	return @$match[1]; 
}
##############################################
//##koruma modu fonksiyonu
##############################################
function hotlink_check($domain){
	$domains=explode(',',str_replace(' ','',$domain));
	$referer=getReferer(); 
	if($referer=="")
		return false;
	$site=array();
	foreach($domains as $value){ 
		$site[]='@'.str_replace('.','\.',$value).'@si'; 
	}
	$MATCH = false;
	foreach($site as $pattern){ 
		if(preg_match($pattern,$referer)) 
			$MATCH=true;
		if($MATCH==true) 
			break; 
	}
	if($MATCH==true) 
		return true; 
	else 
		return false;
}
##############################################
//##vk-token fonksiyonu
##############################################
function get_vk_token()
{
	global $ayar;
	$token_up = time()-3600;
	$pf = unserialize($ayar["platform_vk"]);
	if(isset($pf["tokenuptime"]))
		$token_time = $pf["tokenuptime"];
	else 
		$token_time = 0;
	if($token_time<$token_up)
	{
		insert_vk_token();
		$pf["tokenuptime"] = time();
		$pf = serialize($pf);
		update_option("platform_vk",$pf);
		return get_vk_token_rand();
	}else{
		return get_vk_token_rand();
	}
}
##############################################
//##vk-token çekme ve eskileri silme
##############################################
function insert_vk_token()
{
	global $db,$ayar;
	$pf = unserialize($ayar["platform_vk"]);
	if(!isset($pf["PX_VK_MAIL"]) or !isset($pf["PX_VK_PASS"]))
		return false;
	if($pf["PX_VK_MAIL"]=="" or $pf["PX_VK_PASS"]=="")
		return false;
	$post = "mail=".$pf["PX_VK_MAIL"]."&pass=".$pf["PX_VK_PASS"]."&domain=".urlencode($_SERVER['SERVER_NAME']);
	if(function_exists('curl_init'))
	{
		$c = curl_init(); 
		curl_setopt($c, CURLOPT_BINARYTRANSFER, 1);
		curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($c, CURLOPT_URL, "http://www.pusux.com/vk-token-api/");
		curl_setopt($c, CURLOPT_TIMEOUT, 20);
		curl_setopt($c, CURLOPT_POST, 1);
		curl_setopt($c, CURLOPT_POSTFIELDS, $post);
		$data = curl_exec($c);
	}
	if($data!="")
	{
		$json = json_decode($data,true);
		if(isset($json["error"])) 
			return false;
		$user = $json["user"];
		$token = $json["token"];
		$time = (int)$json["date"];
		$db->query("INSERT INTO vk_token VALUES (NULL,'$user','$token',".$time.")");
		$db->query("DELETE FROM `vk_token` WHERE id not in ( SELECT id FROM ( SELECT id FROM `vk_token` ORDER BY id DESC LIMIT 50)foo);");
		return true;
	}else 
		return false;
}
##############################################
//##vk-veritabanından random token çekme
##############################################
function get_vk_token_rand()
{
	global $db;
	global $ayar;
	$time = time()-604800;
	$token = $db->get_var("select token from vk_token where date>".$time." ORDER BY rand()");
	if(!$token)
	{
		$token = "";
		$pf = unserialize($ayar["platform_vk"]);
		$pf["tokenuptime"] = 0;
		$pf = serialize($pf);
		update_option("platform_vk",$pf);
	}
	return $token;
}
##############################################
//##get user ip adress
##############################################
function get_user_ip(){
	if(getenv("HTTP_CLIENT_IP")){
 		$ip = getenv("HTTP_CLIENT_IP");
 	}elseif(getenv("HTTP_X_FORWARDED_FOR")){
 		$ip = getenv("HTTP_X_FORWARDED_FOR");
 		if(strstr($ip, ',')){
 			$tmp = explode (',', $ip);
 			$ip = trim($tmp[0]);
 		}
 	}else{
 	$ip = getenv("REMOTE_ADDR");
 	}
	return $ip;
}
##############################################
//##gzdecode
##############################################
if (!function_exists('gzdecode'))
{
    function gzdecode($data) 
    {
        return gzinflate(substr($data, 10, -8));
    }
}
?>