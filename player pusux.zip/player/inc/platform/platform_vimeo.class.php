<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_vimeo extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_vimeo"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		$url = "https://player.vimeo.com/video/".$id[1];
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		$url = "https://player.vimeo.com/video/".$id[1]."/config";
		$this->stream_url = $url;
	}
	//stream �retme
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$exec = $this->get_curl($url);
		$djson = json_decode($exec,true);
		if(!isset($djson["request"]["files"]["progressive"]))
			return array();
		$vid = $djson["request"]["files"]["progressive"];
		foreach($vid as $value)
		{
			$key = (int)$value["quality"];
			$data[$key]['tur'] = $value["quality"];
			$data[$key]['kalip'] = $value["url"];
		}
		krsort($data);
		return $data;
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$this->stream_url_generate();
		$data = $this->get_curl($this->stream_url);
		$djson = json_decode($data,true);
		$time = time();
		if(!isset($djson["request"]["files"]["progressive"]))
		{
			$data = $this->get_curl($this->stream_url);
			if(!isset($djson["request"]["files"]["progressive"]))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}
$ooO0000oOo0[] = substr(Licence,20,10);
$oo00000oOo0[] = substr(Licence,30,10);
?>