<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_photos extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_photos"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		if(@$id[3] and $id[3]!="") 
			$key = "?key=".$id[3];
		else 
			$key = "";
		$url = "https://photos.google.com/share/".$id[1]."/photo/".$id[2].$key;
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		if(@$id[3] and $id[3]!="") 
			$key = "?key=".$id[3];
		else 
			$key = "";
		$url = "https://photos.google.com/share/".$id[1]."/photo/".$id[2].$key;
		$this->stream_url = $url;
	}
	//stream �retme
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$exec = $this->get_curl($url);
		$data = array();
		preg_match('@initDataCallback\(\{(.*?)\}\)@si',$exec,$p);
		if(!isset($p[1]) or empty($p[1]))
			return $data;
		preg_match_all('@"(.*?)"@si',$p[1],$p2);
		if(!isset($p2[1]) or empty($p2[1]))
			return $data;
		$k1 = $p2[1][1];
		$k2 = array_slice($p2[1], -2, 1); 
		$k2 = $k2[0];
		if(!preg_match('@https://.*?\.googleusercontent\.com/@si',$k1))
			return $data;
		$k2 = explode(",",$k2);
		$k2 = array_reverse($k2);
		foreach($k2 as $itag)
		{
			$itag = explode("/",$itag);
			$itag = (int)$itag[0];
			if($itag=="18")
			{
				$data['360p']['tur'] = "360p";
				$data['360p']['kalip'] = $k1."=m18";
			}elseif($itag=="22")
			{
				$data['720p']['tur'] = "720p";
				$data['720p']['kalip'] = $k1."=m22";
			}elseif($itag=="37")
			{
				$data['1080p']['tur'] = "1080p";
				$data['1080p']['kalip'] = $k1."=m37";
			}
		}
		$data = array_reverse($data);
		return $data;
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$this->stream_url_generate();
		$data = $this->get_curl($this->stream_url);
		//echo $data;exit;
		$time = time();
		if(preg_match('@<title>Error 404@si',$data))
		{
			$data = $this->get_curl($this->stream_url);
			if(preg_match('@<title>Error 404@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>