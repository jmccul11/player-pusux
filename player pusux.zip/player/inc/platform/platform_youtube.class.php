<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_youtube extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_youtube"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		$url = "https://www.youtube.com/embed/".$id[1];
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		//$url = "http://www.youtube.com/get_video_info?video_id=".$id[1]."&authuser=";
		$url = "https://www.youtube.com/watch?v=".$id[1];
		$this->stream_url = $url;
	}
	//stream �retme
	function DecryptYouTubeCypher($signature)
	{
		$s = $signature;
		$api_file = "./youtube_decrypt.xml";//dirname( __FILE__ )."/youtube_decrypt.xml";
		//if (is_file($api_file))
		//{
			$algos = file_get_contents($api_file);
			$sxe = new SimpleXMLElement($algos);
			$algo = $sxe->xpath('/software/decryption/funcgroup[@siglength="' . strlen($s) . '"]/func');
			if ($algo !== false && !empty($algo))
			{
				//die(print_r($algo));
				foreach ($algo as $func)
				{
					$funcName = (string)$func->name;
					if (!function_exists($funcName))
					{
						eval('function ' . $funcName . '(' . (string)$func->args . '){' . preg_replace('/self::/', "", (string)$func->code) . '}');
					}
				}
				$s = call_user_func((string)$algo[0]->name, $s);
			}
		//}
		$s = ($s == $signature) ? $this->LegacyDecryptYouTubeCypher($s) : $s;
		return $s;
	}
	private function LegacyDecryptYouTubeCypher($signature)
	{
		$s = $signature;
		$sigLength = strlen($s);
		switch ($sigLength)
		{
			case 93:
				$s = strrev(substr($s, 30, 57)) . substr($s, 88, 1) . strrev(substr($s, 6, 23));
				break;
			case 92:
				$s = substr($s, 25, 1) . substr($s, 3, 22) . substr($s, 0, 1) . substr($s, 26, 16) . substr($s, 79, 1) . substr($s, 43, 36) . substr($s, 91, 1) . substr($s, 80, 3);
				break;
			case 90:
				$s = substr($s, 25, 1) . substr($s, 3, 22) . substr($s, 2, 1) . substr($s, 26, 14) . substr($s, 77, 1) . substr($s, 41, 36) . substr($s, 89, 1) . substr($s, 78, 3);
				break;
			case 89:
				$s = strrev(substr($s, 79, 6)) . substr($s, 87, 1) . strrev(substr($s, 61, 17)) . substr($s, 0, 1) . strrev(substr($s, 4, 56));
				break;
			case 88:
				$s = substr($s, 7, 21) . substr($s, 87, 1) . substr($s, 29, 16) . substr($s, 55, 1) . substr($s, 46, 9) . substr($s, 2, 1) . substr($s, 56, 31) . substr($s, 28, 1);
				break;
			case 87:
				$s = substr($s, 6, 21) . substr($s, 4, 1) . substr($s, 28, 11) . substr($s, 27, 1) . substr($s, 40, 19) . substr($s, 2, 1) . substr($s, 60);
				break;
			case 84:
				$s = strrev(substr($s, 71, 8)) . substr($s, 14, 1) . strrev(substr($s, 38, 32)) . substr($s, 70, 1) . strrev(substr($s, 15, 22)) . substr($s, 80, 1) . strrev(substr($s, 0, 14));
				break;
			case 81:
				$s = substr($s, 56, 1) . strrev(substr($s, 57, 23)) . substr($s, 41, 1) . strrev(substr($s, 42, 14)) . substr($s, 80, 1) . strrev(substr($s, 35, 6)) . substr($s, 0, 1) . strrev(substr($s, 30, 4)) . substr($s, 34, 1) . strrev(substr($s, 10, 19)) . substr($s, 29, 1) . strrev(substr($s, 1, 8)) . substr($s, 9, 1);
				break;
			case 80:
				$s = substr($s, 1, 18) . substr($s, 0, 1) . substr($s, 20, 48) . substr($s, 19, 1) . substr($s, 69, 11);
				break;
			case 79:
				$s = substr($s, 54, 1) . strrev(substr($s, 55, 23)) . substr($s, 39, 1) . strrev(substr($s, 40, 14)) . substr($s, 78, 1) . strrev(substr($s, 35, 4)) . substr($s, 0, 1) . strrev(substr($s, 30, 4)) . substr($s, 34, 1) . strrev(substr($s, 10, 19)) . substr($s, 29, 1) . strrev(substr($s, 1, 8)) . substr($s, 9, 1);
				break;
			default:
				$s = $signature;
		}
		return $s;
	}
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$exec = $this->get_curl($url);
		//echo $exec;exit;
		preg_match('@"url_encoded_fmt_stream_map":"(.*?)"@si',$exec,$fst);
		if(!isset($fst[0]))
		{
			if(preg_match('@watch7-player-age-gate-content@si',$exec))//
			{
				$this->error = "3";
			}
			return array();
		}			
		$fst = json_decode('{'.$fst[0].'}',true);
		$fst = $fst["url_encoded_fmt_stream_map"];
		$fst = explode(",",$fst);
		foreach($fst as $i=>$value)
		{
			parse_str($value, $query);
			//print_r($query);
			$query["url"] = preg_replace('@https://(.*?)/videoplayback@si','https://redirector.googlevideo.com/videoplayback',$query["url"]);
			$query["url"] = preg_replace('@http://(.*?)/videoplayback@si','https://redirector.googlevideo.com/videoplayback',$query["url"]);
			if(isset($query["s"]))
			{
				$sig = $this->DecryptYouTubeCypher($query["s"]);
				$sig = "&signature=".$sig;
			}elseif(isset($query["sig"]))
			{
				$sig = $this->DecryptYouTubeCypher($query["sig"]);
				$sig = "&signature=".$sig;
			}elseif(isset($query["signature"]))
			{
				$sig = $this->DecryptYouTubeCypher($query["signature"]);
				$sig = "&signature=".$sig;
			}
			else 
				$sig = "";
			if($query["itag"]=="37")
			{
				$data['1080p']['tur'] = "1080p";
				$data['1080p']['kalip'] = urldecode($query["url"]).$sig;
			}elseif($query["itag"]=="22")
			{
				$data['720p']['tur'] = "720p";
				$data['720p']['kalip'] = urldecode($query["url"]).$sig;
			}elseif($query["itag"]=="44")
			{
				$data['480p']['tur'] = "480p";
				$data['480p']['kalip'] = urldecode($query["url"]).$sig;
			}elseif($query["itag"]=="18")
			{
				$data['360p']['tur'] = "360p";
				$data['360p']['kalip'] = urldecode($query["url"]).$sig;
			}
		}
		//fake 480p 
		if(!isset($data['480p']) and isset($data['360p']))
		{
			$data['480p'] = $data['360p'];
			$data['480p']['tur'] = "480p";
		}
		rsort($data);
		return $data;
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$this->stream_url_generate();
		$data = $this->get_curl($this->stream_url);
		//echo $data;exit;
		$time = time();
		if(preg_match('@watch7-player-age-gate-content@si',$data))//
		{
			$this->error = "3";
			return;
		}
		if(!preg_match('@ytplayer@si',$data))
		{
			$data = $this->get_curl($this->stream_url);
			if(!preg_match('@ytplayer@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>