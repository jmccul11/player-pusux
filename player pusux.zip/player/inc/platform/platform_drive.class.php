<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_drive extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_drive"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		$url = "https://drive.google.com/file/d/".$id[1]."/view";
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		$url = "https://docs.google.com/get_video_info?docid=".$id[1]."&authuser=";
		$this->stream_url = $url;
	}
	//stream �retme
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$exec = $this->get_curl($url,true,true);
		
		parse_str($exec, $query);
		if(!isset($query["url_encoded_fmt_stream_map"]))
			return array();
		$fst = $query["url_encoded_fmt_stream_map"];
		$fst = explode(",",$fst);
		
		foreach($fst as $i=>$value)
		{
			parse_str($value, $query);
			$query["url"] = preg_replace('@https://(.*?)/videoplayback@si','https://redirector.googlevideo.com/videoplayback',$query["url"]);
			if($query["itag"]=="37")
			{
				$data['1080p']['tur'] = "1080p";
				$data['1080p']['kalip'] = urldecode($query["url"]);
			}elseif($query["itag"]=="22")
			{
				$data['720p']['tur'] = "720p";
				$data['720p']['kalip'] = urldecode($query["url"]);
			}elseif($query["itag"]=="59")
			{
				$data['480p']['tur'] = "480p";
				$data['480p']['kalip'] = urldecode($query["url"]);
			}elseif($query["itag"]=="18")
			{
				$data['360p']['tur'] = "360p";
				$data['360p']['kalip'] = urldecode($query["url"]);
			}
		}
		return $data;
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$this->stream_url_generate();
		$data = $this->get_curl($this->stream_url,true,false);
		$time = time();
		if(!preg_match('@status=ok@si',$data))
		{
			$data = $this->get_curl($this->stream_url,true,false);
			if(!preg_match('@status=ok@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>