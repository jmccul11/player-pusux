<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_mail extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_mail"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		if(!isset($id[3])) $id[3] = "";
		if($id[3]=="inbox")
			$url = "https://videoapi.my.mail.ru/videos/embed/inbox/".$id[1]."/_myvideo/".$id[2].".html";
		elseif($id[3]=="inbox")
			$url = "https://videoapi.my.mail.ru/videos/embed/bk/".$id[1]."/_myvideo/".$id[2].".html";
		elseif($id[3]=="v")
			$url = "https://videoapi.my.mail.ru/videos/embed/v/".$id[1]."/_groupvideo/".$id[2].".html";
		else
			$url = "https://videoapi.my.mail.ru/videos/embed/mail/".$id[1]."/_myvideo/".$id[2].".html";
		
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		if(!isset($id[3])) 
			$id[3] = "";
		if($id[3]=="inbox")
			$url = "https://videoapi.my.mail.ru/videos/inbox/".$id[1]."/_myvideo/".$id[2].".json";
		elseif($id[3]=="inbox")
			$url = "https://videoapi.my.mail.ru/videos/bk/".$id[1]."/_myvideo/".$id[2].".json";
		elseif($id[3]=="v")
			$url = "https://videoapi.my.mail.ru/videos/v/".$id[1]."/_groupvideo/".$id[2].".json";
		else
			$url = "https://videoapi.my.mail.ru/videos/mail/".$id[1]."/_myvideo/".$id[2].".json";
		
		$this->stream_url = $url;
	}
	public function stream_data_generate()
	{
		return array();
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$this->stream_url_generate();
		$url = $this->stream_url;
		$data = $this->get_curl($url);
		$time = time();
		$data = json_decode($data,true);
		if(isset($data["error"]) and !empty($data["error"]))
		{
			$data = $this->get_curl($url);
			$data = json_decode($data,true);
			if(isset($data["error"]) and !empty($data["error"]))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>