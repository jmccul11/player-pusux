<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class pusux_platform {
	public $url_data = "";
	public $url_platform = "";
	public $status = "";
	public $url = "";
	public $mode = "flash";
	public $stream_url = "";
	public $error = "";//1 stream bulamamış ---2 kırık tespiti 
	public $template = "";
	public $dbdata = array();
	public $type = "classic";
	public $type_id = "";
	public $subtitle = "";
	public function get_data()
	{
		$this->url_generate();
		if($this->status=="1" or $this->status=="3" or $this->status=="5")
		{
			$broken = $this->broken_add($this->type,$this->url,$this->type_id);
			if($broken["status"]==true)
			{
				$bro_id = $broken["id"];
				$this->broken_test($bro_id,$this->url);
			}
			if($this->error!="")
			{
				$this->template = "error";
			}
			if($this->error=="3")
			{
				$this->template = "redirect";
			}
		}
		$this->status();
		if($this->status=="2" or $this->status=="3")
		{
			$this->stream_url_generate();
			$stream = $this->stream_data_generate();
			if($this->error!="")
			{
				$this->template = "error";
			}
			if($this->error=="3")
			{
				$this->template = "redirect";
			}
		}else{
			$stream = array();
		}
		//genel veri çıktısı
		$data = array();
		$data["platform"] = $this->url_platform;
		$data["error"] = $this->error;
		$data["template"] = $this->template;
		$data["jwdata"] = $this->template_jwplayer();
		$data["mode"] = $this->mode;
		$data["url"] = $this->url;
		$data["url_data"] = $this->url_data;
		$data["stream"] = $stream;
		$data["subtitle"] = $this->subtitle;
		return $data;
	}
	public function get_curl($link,$https=true,$ipresolve6=false)
	{
		if (function_exists('curl_init')) {
		$useragent =  'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36';
		$c = curl_init(); 
		curl_setopt($c, CURLOPT_BINARYTRANSFER, 1);
		curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
		//curl_setopt($c, CURLOPT_HEADER, 1);
		curl_setopt($c, CURLOPT_URL, $link);
		curl_setopt($c, CURLOPT_AUTOREFERER, 1);
		curl_setopt($c, CURLOPT_REFERER, $link);
		curl_setopt($c, CURLOPT_TIMEOUT, 20);
		curl_setopt($c, CURLOPT_USERAGENT, $useragent);
		@curl_setopt($c, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
		if($ipresolve6==true)
		{
			@curl_setopt($c, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V6 );
		}
		if($https==true)
		{
			curl_setopt($c, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
		}
		return curl_exec($c);
		} else {
			return file_get_contents($link);
		}
	}
	public function broken_add($type,$classic,$reg_id)
	{
		global $db;//true kırık testi yapılcak
		$data = array();
		$classic = urlencode($classic);
		$latest = $db->get_row("select id,status,time from broken_link where type='$type' and classic='$classic' and reg_id='$reg_id'");
		if(!$latest)
		{
			$get_data = get_data();
			$get_data = $get_data["data"];
			$db->query("INSERT INTO broken_link (type, get_data, classic, reg_id, status, time) VALUES ('$type','$get_data','$classic','$reg_id',0,".time().")");	
			//db kaydı yokmuş eklendi kırık testi yapılacak
			$data["id"] = $db->insert_id;
			$data["status"] = true;
		}else{
			$preday = time()-86400;
			if($latest->status=="1")
			{
				//zaten kırık olarak eklenmiş.
				$data["id"] = $latest->id;
				$data["status"] = false;
				$this->error = "2";
			}elseif($latest->time<$preday)
			{
				//son kontrol 1 günden önce kırık testi yapıalcak
				$data["id"] = $latest->id;
				$data["status"] = true;
			}else{
				//son test 1 gün içinde yapılmış 
				$data["id"] = $latest->id;
				$data["status"] = false;
			}
		}
		return $data;
	}
	
	public function template_jwplayer()
	{
		$jwdata = $this->dbdata;
		$data = array();
		$data["jw_theme"] = $jwdata["jw_theme"];
		$data["jw_background"] = $jwdata["jw_background"];
		$data["jw_logo"] = $jwdata["jw_logo"];
		$data["jw_logourl"] = $jwdata["jw_logourl"];
		$data["jw_licence"] = $jwdata["jw_licence"];
		$data["jw_mobile_mode"] = $jwdata["jw_mobile_mode"];
		$data["jw_session"] = $jwdata["jw_session"];
		$data["jw_autostart"] = $jwdata["jw_autostart"];
		return $data;
	}
	public function status()
	{
		$status = $this->status;
		$url = $this->url;
		if(($status=="0" or $status=="1") and $url!="")
		{
			$this->template = "redirect";
			//durum 1 ise 
			if($this->error=="2")
			{
				$this->template = "error";
			}
			//$this->go_redirect($url);
			//exit("yönlendirme çalıştı");
		}elseif($status=="2" or $status=="3")
		{
			$this->template = "jwplayer";
		}elseif($status=="4" or $status=="5")
		{
			$this->template = "alternative";
			if($this->error=="2")
			{
				$this->template = "error";
			}
		}
	}
	private function go_redirect($url, $time = 0){
		if ($time): 
			@header("Refresh: {$time}; url={$url}");
			echo '
			<!DOCTYPE HTML>
			<html lang="en-US">
				<head>
					<meta charset="UTF-8">
					<meta http-equiv="refresh" content="'.$time.';url='.$url.'">
					<script type="text/javascript">
						window.location.href = "'.$url.'"
					</script>
					<title>Page Redirection</title>
				</head>
				<body>
					<!-- Note: don\'t tell people to `click` the link, just tell them that it is a link. -->
					If you are not redirected automatically, follow the <a href=\''.$url.'\'>link to example</a>
				</body>
			</html>
			';
			
		else:
			@header("Location: {$url}");
			echo '
			<!DOCTYPE HTML>
			<html lang="en-US">
				<head>
					<meta charset="UTF-8">
					<meta http-equiv="refresh" content="'.$time.';url='.$url.'">
					<script type="text/javascript">
						window.location.href = "'.$url.'"
					</script>
					<title>Page Redirection</title>
				</head>
				<body>
					<!-- Note: don\'t tell people to `click` the link, just tell them that it is a link. -->
					If you are not redirected automatically, follow the <a href=\''.$url.'\'>link to example</a>
				</body>
			</html>
			';
		endif;
		exit();
	}
}
$oo0OO00oOo0[] = substr(Licence,0,10);
$ooOO000o0o0[] = substr(Licence,10,10);
?>