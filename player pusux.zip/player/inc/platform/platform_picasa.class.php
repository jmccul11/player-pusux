<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_picasa extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_picasa"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		if(isset($id[5]))
			$id[5] = "?authkey=".$id[5];
		else 
			$id[5] = "";
		$url = "https://picasaweb.google.com/".$id[1]."/".$id[4].$id[5]."#".$id[3];
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		if(@$id[5] and $id[5]!="") 
			$key = "&urlredir=1&authkey=".$id[5];
		else 
			$key = "";
		$url = "https://picasaweb.google.com/data/feed/tiny/user/".$id[1]."/albumid/".$id[2]."/photoid/".$id[3]."?alt=jsonm".$key;
		$this->stream_url = $url;
	}
	//stream �retme
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$exec = $this->get_curl($url);
		$dec = json_decode($exec,true);
		//return $dec["feed"];
		if(@$dec["feed"]["entry"]) $dec = $dec["feed"]["entry"]["0"]["media"]["content"];
		else $dec = $dec["feed"]["media"]["content"];
		
		$player = array("360p","720p","1080p","2048p");
		//print_R($dec);exit;
		if(count($dec)<1)
		{
			$this->error = "1";
			return array();
		}
		$i = 0;
		$data = array();
		foreach($dec as $dt)
		{
			if($dt["type"]=="video/mpeg4")
			{
				if($i=="1")
				{
					$data["480p"]['tur'] = "480p";
					$data["480p"]['kalip'] = $dt["url"];
				}
				$data[$player[$i]]['tur'] = $player[$i];
				$data[$player[$i]]['kalip'] = $dt["url"];
				$i++;
			}
		}
		$data = array_reverse($data);
		return $data;
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$data = $this->get_curl($url);
		$time = time();
		if(!preg_match('@faceProcessing@si',$data))
		{
			$data = $this->get_curl($url);
			if(!preg_match('@faceProcessing@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}/* elseif(!preg_match('@faceProcessing@si',$data))
		{
			
		} */
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>