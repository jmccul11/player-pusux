<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_myvideo extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_myvideo"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		$url = "http://embed.myvideo.az/flv_player/player.php?video_id=".$id[1].".mp4";
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		$url = "http://www.myvideo.az/v/".$id[1];
		$this->stream_url = $url;
	}
	//stream �retme
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$data = $this->get_curl($url,false);
		//print_R($data);exit;
		/* preg_match('@sources :.*?\[(.*?)\]@si',$data,$sources);
		preg_match_all('@file.*?"(.*?)".*?label.*?\'(.*?)\'@si',$sources[0],$video);
		$data = array();
		$i = 0;
		foreach($video[1] as $value)
		{
			$data[$video[2][$i]]['tur'] = $video[2][$i];
			$data[$video[2][$i]]['kalip'] = $value;
			$i++;
		} */
		preg_match('@sources.*?:.*?file.*?"(.*?)"@si',$data,$video);
		$data = array();
		if(!isset($video[1])) return array();
		$data["SD"]['tur'] = "SD";
		$data["SD"]['kalip'] = $video[1];
		preg_match('@http://(.*?)\.myvideo\.az/secure/(.*?)/.*?/(.*?)\.mp4@si',$video[1],$video);
		if(isset($video[1]))
		{
			$data["HD"]['tur'] = "HD";
			$data["HD"]['kalip'] = "http://".$video[1].".myvideo.az/secure/".$video[2]."/".$video[3].".mp4";
		}
		//print_R($video);
		return $data;
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$this->stream_url_generate();
		$data = $this->get_curl($this->stream_url,false);
		$time = time();
		if(preg_match('@<div class="alert_head">@si',$data))
		{
			$data = $this->get_curl($this->stream_url,false);
			if(preg_match('@<div class="alert_head">@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>