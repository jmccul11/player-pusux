<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_facebook extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_facebook"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		$url = "https://www.facebook.com/video.php?v=".$id[1];
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		$url = "https://www.facebook.com/video.php?v=".$id[1];
		$this->stream_url = $url;
	}
	//stream �retme
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$exec = $this->get_curl($url);
		preg_match('@"sd_src_no_ratelimit":"(.*?)"@si',$exec,$sd);
		$data = array();
		if(isset($sd[1]) and !empty($sd[1]))
		{
			$json = '{"sd":"'.$sd[1].'"}';
			$json = json_decode($json);
			$data['SD']['kalip'] = $json->sd;
			$data['SD']['tur'] = "SD";
		}
		preg_match('@"hd_src_no_ratelimit":"(.*?)"@si',$exec,$hd);
		if(isset($hd[1]) and !empty($hd[1]))
		{
			$json = '{"hd":"'.$hd[1].'"}';
			$json = json_decode($json);
			$data['HD']['kalip'] = $json->hd;
			$data['HD']['tur'] = "HD";
		}
		//rsort($data);
		return $data;
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$this->stream_url_generate();
		$data = $this->get_curl($this->stream_url);
		//echo $data;exit;
		$time = time();
		if(preg_match('@onclick="history\.back\(\);"@si',$data))
		{
			$data = $this->get_curl($this->stream_url);
			if(preg_match('@onclick="history\.back\(\);"@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>