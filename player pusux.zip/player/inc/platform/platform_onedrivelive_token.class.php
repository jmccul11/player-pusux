<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_onedrivelive_token{ 
	private $cfile = "./cookie.txt";
	private $ua = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36";
	private function key_al($url){
		$curl    =    curl_init();
		curl_setopt($curl,CURLOPT_URL,$url);
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($curl,CURLOPT_USERAGENT,$this->ua);
		curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
		curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl,CURLOPT_COOKIEFILE,$this->cfile);
		curl_setopt($curl,CURLOPT_COOKIEJAR,$this->cfile);
		$exec = curl_exec($curl);
		//curl_close($curl);
		preg_match('@urlPost:\'(.*?)\'@si',$exec,$key);
		$data["post_url"] = @$key[1];
		preg_match('@name="PPFT".*?value="(.*?)"@si',$exec,$key);
		$data["PPFT"] = @$key[1];
		$data["type"] = "11";
		$data["SI"] = "Oturum aç";
		return $data;
	}
	private function get_login($url,$mail,$pass,$si,$type,$ppft){
		$fields = array(
            'loginfmt' => $mail,
			'passwd' => $pass,
			'SI' => $si,
			'login' => $mail,
			'type' => $type,
			'PPFT' => $ppft
        );
		$field_string = http_build_query($fields);
		$curl    =    curl_init();
		curl_setopt($curl,CURLOPT_URL,$url);
		curl_setopt($curl, CURLOPT_HEADER, 1);
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($curl,CURLOPT_USERAGENT,$this->ua);
		curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl,CURLOPT_POST, 1);
		curl_setopt($curl,CURLOPT_POSTFIELDS, $field_string);
		curl_setopt($curl,CURLOPT_COOKIEFILE,$this->cfile);
		curl_setopt($curl,CURLOPT_COOKIEJAR,$this->cfile);
		$exec = curl_exec($curl);
		//curl_close($curl);
		$headers = explode("\n", $exec);
		//print_R($headers);exit;
		foreach($headers as $header) {
			if (stripos($header, 'Location:') !== false) {
				$loc = explode("Location:", $header);
				$loc = trim($loc[1]);
				break;
			}else $loc = "";
		}
		return $loc;
	}
	private function get_token($loc)
	{
		$curl    =    curl_init();
		curl_setopt($curl,CURLOPT_URL,$loc);
		curl_setopt($curl, CURLOPT_HEADER, 1);
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($curl,CURLOPT_USERAGENT,$this->ua);
		curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl,CURLOPT_COOKIEFILE,$this->cfile);
		curl_setopt($curl,CURLOPT_COOKIEJAR,$this->cfile);
		$exec = curl_exec($curl);
		//curl_close($curl);
		$headers = explode("\n", $exec);
		foreach($headers as $header) {
			if (preg_match('@Location@si',$header)) {
				$loc = explode("Location:", $header);
				$loc = trim($loc[1]);
				break;
			}else $loc = "";
		}
		return $loc;
	}
	public function get_data($resid)
	{
		$mail = PX_ONEDRIVE_MAIL;
		$pass = PX_ONEDRIVE_PASS;
		$this->cfile = "./".md5(time().rand(0,99)).".txt";
		$exresid = explode("!",$resid);
		$login_resid = $exresid[0]."!";
		$token_resid = $resid;
		$login_url = "https://login.live.com/login.srf?wp=MBI_SSL_SHARED&wreply=https:%2F%2Fonedrive.live.com:443%2Fservererror.aspx%3Fresid%3D".$login_resid;
		$token_url = "https://onedrive.live.com/download?resid=".$token_resid;
		
		$loginkey = $this->key_al($login_url);
		
		$login = $this->get_login($loginkey["post_url"],$mail,$pass,$loginkey["SI"],$loginkey["type"],$loginkey["PPFT"]);
		//echo $login;exit;
		if($login=="")
		{
			@unlink($this->cfile);
			return "";
		}
		$token = $this->get_token($token_url);
		if($token=="")
		{
			@unlink($this->cfile);
			return "delete";
		}
		elseif(preg_match('@login\.live\.com@si',$token))
		{
			@unlink($this->cfile);
			return "";
		}
		$url = explode("/",$token);
		array_pop($url);
		$url = implode("/",$url);
		@unlink($this->cfile);
		return $url;
	}
}
?>