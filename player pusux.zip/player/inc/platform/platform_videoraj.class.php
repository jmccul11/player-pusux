<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_videoraj extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_videoraj"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		$url = "http://www.videoraj.to/embed.php?id=".$id[1];
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		$url = "";
		$this->stream_url = $url;
	}
	public function stream_data_generate()
	{
		return array();
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$url_data = $this->url_data;
		$data = $this->get_curl($url,false);
		preg_match('@key:.*?"(.*?)"@si',$data,$key);
		if(!isset($key[1])) return false;
		$url2 = "http://www.videoraj.to/api/player.api.php?file=;".$url_data[1]."&key=".urlencode($key[1]);
		//echo $url;exit;
		$data = $this->get_curl($url2,false);
		$time = time();
		if(preg_match('@error@si',$data))
		{
			$data = $this->get_curl($url,false);
			preg_match('@key:.*?"(.*?)"@si',$data,$key);
			if(!isset($key[1])) return false;
			$url2 = "http://www.videoraj.to/api/player.api.php?file=;".$url_data[1]."&key=".urlencode($key[1]);
			$data = $this->get_curl($url2,false);
			if(preg_match('@error@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>