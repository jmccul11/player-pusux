<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_vk extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_vk"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link �retme
	public function url_generate()
	{
		$id = $this->url_data;
		$url = "http://vk.com/video_ext.php?oid=".$id[1]."&id=".$id[2]."&hash=".$id[3]."&hd=2";
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		$url = "";
		$this->url_data = $id;
		$this->stream_url = $url;
	}
	public function stream_data_generate()
	{
		return array();
	}
	//k�r�k link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$data = $this->get_curl($url);
		//echo $data;exit;
		$time = time();
		if(preg_match('@video has been removed|Video not found@si',$data))
		{
			$data = $this->get_curl($url);
			if(preg_match('@video has been removed|Video not found@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>