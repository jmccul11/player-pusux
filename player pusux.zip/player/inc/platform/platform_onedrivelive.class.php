<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_onedrivelive extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_onedrivelive"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link üretme
	public function url_generate()
	{
		$id = $this->url_data;
		$exresid = explode("!",$id[1]);
		$cid = $exresid[0];
		$url = "https://onedrive.live.com/embed?cid=".$cid."&resid=".urlencode($id[1])."&authkey=".$id[2];
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		$exresid = explode("!",$id[1]);
		$cid = $exresid[0];
		$url = "https://onedrive.live.com/embed?cid=".$cid."&resid=".urlencode($id[1])."&authkey=".$id[2];
		$this->stream_url = $url;
	}
	//stream üretme
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$opts = array(
		  'http'=>array(
			'method'=>"GET",
			'header'=>"Accept-Encoding: gzip, deflate, sdch\r\nAccept-Language: tr-TR,tr;q=0.8,en-US;q=0.6,en;q=0.4\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.103 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nCache-Control: max-age=0\r\nAConnection: keep-alive\r\n"
		  )
		);
		$context = stream_context_create($opts);
		$file = gzdecode(file_get_contents($url, false, $context));
		preg_match('@"urls":{(.*?)}@si',$file,$json);
		$json = json_decode("{".$json[1]."}");
		//print_R($json);
		$down = $json->download;
		$down = explode("?",$down);
		$data["HD"]['tur'] = "HD";
		$data["HD"]['kalip'] = $down[0];
		return $data;
	}
	//kırık link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$opts = array(
		  'http'=>array(
			'method'=>"GET",
			'header'=>"Accept-Encoding: gzip, deflate, sdch\r\nAccept-Language: tr-TR,tr;q=0.8,en-US;q=0.6,en;q=0.4\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.103 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nCache-Control: max-age=0\r\nAConnection: keep-alive\r\n"
		  )
		);
		$context = stream_context_create($opts);
		$data = gzdecode(file_get_contents($url, false, $context));
		$time = time();
		if(!preg_match('@"urls":{@si',$data))
		{
			$data =  gzdecode(file_get_contents($url, false, $context));
			if(!preg_match('@"urls":{@si',$data))
			{
				$referer = urlencode($db->escape(@$_SERVER['HTTP_REFERER']));
				$db->query("UPDATE broken_link SET status=1,referer='$referer',time=$time WHERE id=$id");
				$this->error = "2";
			}else{
				$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
			}
		}
		else{
			$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
		}
	}
}


?>