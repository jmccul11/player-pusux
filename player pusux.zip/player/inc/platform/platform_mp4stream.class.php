<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class platform_mp4stream extends pusux_platform{
	function __construct($get_db)
	{
	   $this->dbdata = $get_db;
	   $pf = unserialize($get_db["platform_mp4stream"]);
	   $this->mode = $pf["mode"];
	   $this->status = $pf["status"];
	}
	//saf link üretme
	public function url_generate()
	{
		$id = $this->url_data;
		$url = urldecode($id[1]);
		$this->url = $url;
	}
	//api linki
	public function stream_url_generate()
	{
		$id = $this->url_data;
		$url = urldecode($id[1]);
		$this->stream_url = $url;
	}
	//stream üretme
	public function stream_data_generate()
	{
		$url = $this->stream_url;
		$data = array();
		$data['Stream']['tur'] = "Stream";
		$data['Stream']['kalip'] = $url;
		
		return $data;
	}
	//kırık link test fonksiyonu
	public function broken_test($id,$url)
	{
		global $db;
		$data = $this->get_curl($url);
		$time = time();
		$db->query("UPDATE broken_link SET time=$time WHERE id = $id");
	}
}


?>