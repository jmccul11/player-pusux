<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
	$url_data = $data["url_data"];
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
	<head>
		<title>Pusux Player <?=$ayar["vercion"]?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<style type="text/css">html,body{margin:0px;padding:0px;height: 100% !important;}#embed_video_<?=$url_data[1]?>E{z-index:1;position:absolute;width: 100% !important;height: 100% !important;}a{cursor:pointer}iframe{border:0;}</style>
	</head>
	<body>
		<?php if(PX_MOBIL=="1"): ?>
		<iframe id="embed_video_<?=$url_data[1]?>E" src="https://docs.google.com/file/d/<?=$url_data[1]?>/preview"></iframe>
		<?php else: ?>
		<object id="embed_video_<?=$url_data[1]?>E" name="embed_video_<?=$url_data[1]?>E" type="application/x-shockwave-flash" data="https://video.google.com/get_player?docid=<?=$url_data[1]?>&amp;ps=docs&amp;partnerid=30&amp;cc_load_policy=1">
			<param name="allowScriptAccess" value="always">
			<param name="wmode" value="opaque">
			<param name="allowFullScreen" value="true">
			<param name="bgcolor" value="#000000">
			<param name="flashvars" value="">
		</object>
		<?php endif; ?>
		<?=stripcslashes($ayar["htmlcode"])?>
	</body>
</html>