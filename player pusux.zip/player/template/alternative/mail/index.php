<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
if(!isset($_GET["mail_protect"]))
{
	$url = "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'];
	$separator = (parse_url($url, PHP_URL_QUERY) == NULL) ? '?' : '&';
	$url .= $separator . 'mail_protect=http://videoapi.mail.ru';
	go_redirect($url);
	exit;
}
$url_data = $data["url_data"];
$kadi = $url_data[1];
$id = $url_data[2];
if(isset($url_data[3]))
	$inbox = $url_data[3];
else 
	$inbox = "";

if($inbox=="bk")
{
	$metadataUrl = "http%3A//videoapi.my.mail.ru/videos/bk/".$kadi."/_myvideo/".$id.".json";
	$movieSrc = "bk/".$kadi."/_myvideo/".$id;
}
elseif($inbox=="inbox")
{
	$metadataUrl = "http%3A//videoapi.my.mail.ru/videos/inbox/".$kadi."/_myvideo/".$id.".json";
	$movieSrc = "inbox/".$kadi."/_myvideo/".$id;
}elseif($inbox=="v")
{
	$metadataUrl = "http%3A//videoapi.my.mail.ru/videos/v/".$kadi."/_myvideo/".$id.".json";
	$movieSrc = "v/".$kadi."/_myvideo/".$id;
}else
{
	$metadataUrl = "http%3A//videoapi.my.mail.ru/videos/mail/".$kadi."/_myvideo/".$id.".json";
	$movieSrc = "mail/".$kadi."/_myvideo/".$id;
}
?>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Pusux Player <?=$ayar["vercion"]?></title>
	<meta name="robots" content="noindex, nofollow" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="cache-control" content="no-cache" />
	<meta http-equiv="pragma" content="no-cache" />
	<link href='https://fonts.googleapis.com/css?family=Days+One' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="<?=get_home_url()?>/template/alternative/mail/video_61.css" />
	<link rel="stylesheet" type="text/css" href="<?=get_home_url()?>/template/alternative/mail/player_iframe_61.css" />
</head>
<body>
	<script type="text/javascript" src="<?=get_home_url()?>/template/alternative/mail/player.min_61.js"></script>
	<div style="position:fixed;text-align:center;width:100%;right:0;left:0;top:0;height:18px;background:#fff;color:#000;z-index: 99999;padding: 10px;"><font color="red">"Video is not avaliable"</font> hatası alıyorsanız <a style="color:red;text-style:none;" href="#" onclick="location.reload(true); return false;">buraya tıklayınız.</a></div>	
	<div id="container_div">
	<object width="100%" height="100%" id="b-flash-wrapper" type="application/x-shockwave-flash" data="https://my1.imgsmail.ru/r/video2/uvpv3.swf?61" style="position:absolute;">
	<param name="allowFullScreen" value="true">
	<param name="AllowScriptAccess" value="always">
	<param name="wmode" value="transparent">
	<param name="flashvars" value="metadataUrl=<?=$metadataUrl?>&amp;autoplay=0&amp;time=0&amp;locationHref=&amp;host=&amp;referrer=&amp;showPauseRoll=0&amp;externalLocation=&amp;relatedLimit=16">
	</object>
	<div id="internal_div" style="z-index: 3; position: absolute; width: 48%; height: 93%;" onclick="return false;"></div>
	<div id="internal_div" style="width: 48%; height: 93%; position: absolute; right: 2px; z-index: 1;" onclick="return false;"></div>
	</div>
	<?=stripcslashes($ayar["htmlcode"])?>
</body>
</html>