<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
	$url_data = $data["url_data"];
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
	<head>
		<title>Pusux Player <?=$ayar["vercion"]?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<style type="text/css">html,body{margin:0px;padding:0px;height: 100% !important;}#embed_video_<?=$url_data[1]?>E{z-index:1;position:absolute;width: 100% !important;height: 100% !important;}a{cursor:pointer}iframe{border:0;}</style>
	</head>
	<body>
		<?php if(PX_MOBIL=="1"): ?>
		<iframe id="embed_video_<?=$url_data[1]?>E" src="https://ok.ru/videoembed/<?=$url_data[1]?>"></iframe>
		<?php else: ?>
		<object id="embed_video_<?=$url_data[1]?>E" name="embed_video_<?=$url_data[1]?>E" type="application/x-shockwave-flash" data="http://st.mycdn.me/static/MegaPlayer/8-1-1/vp11.swf?preferHd=1&amp;noUpload=1&amp;bigLike=1&amp;adLogic=15,0,3,1200&amp;saveLastPlayingTimeFrom=900&amp;enabledLocalStorage=1">
			<param name="allowScriptAccess" value="always">
			<param name="wmode" value="opaque">
			<param name="allowFullScreen" value="true">
			<param name="bgcolor" value="#000000">
			<param name="flashvars" value="location=AnonymVideoEmbed&amp;locale=en&amp;metadataUrl=http://www.odnoklassniki.ru%2Fdk%3Fcmd%3DvideoPlayerMetadata%26mid%3D<?=$url_data[1]?>&amp;playerId=embed_video_<?=$url_data[1]?>&amp;autoplay=false&amp;wmode=opaque&amp;stageVideo=false">
		</object>
		<?php endif; ?>
		<?=stripcslashes($ayar["htmlcode"])?>
	</body>
</html>