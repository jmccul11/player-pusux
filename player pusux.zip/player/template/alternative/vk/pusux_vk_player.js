function qsEncode(a) {
	var b, _0x36a2x4 = [];
	for (b in a) {
		"user" != b && _0x36a2x4["push"](encodeURIComponent(b) + "=" + encodeURIComponent(a[b]))
	};
	return _0x36a2x4["sort"](),
	_0x36a2x4["join"]("&")
}
function re(a) {
	try {
		a && a["parentNode"] && a["parentNode"]["removeChild"](a)
	} catch(t) {}
}
function isString(a) {
	return "string" == typeof a
}
function isArray(a) {
	return "[object Array]" === Object["prototype"]["toString"]["call"](a)
}
function isFunction(a) {
	return "[object Function]" === Object["prototype"]["toString"]["call"](a)
}
function timeNow() {
	return + new Date
}
function rand(a, b) {
	return Math["floor"](Math["random"]() * (b - a + 1) + a)
}
function each(a, b) {
	var c, _0x36a2xc = 0,
	_0x36a2xd = a["length"];
	if (void(0) === _0x36a2xd) {
		for (c in a) {
			if (b["call"](a[c], c, a[c]) === !1) {
				break
			}
		}
	} else {
		for (var d = a[0]; _0x36a2xd > _0x36a2xc && b["call"](d, _0x36a2xc, d) !== !1; d = a[++_0x36a2xc]) {}
	};
	return a
}
function extend() {
	var a, _0x36a2x3 = arguments,
	_0x36a2x4 = _0x36a2x3[0] || {},
	_0x36a2xc = 1,
	_0x36a2xd = _0x36a2x3["length"],
	_0x36a2xe = !1;
	for ("boolean" == typeof _0x36a2x4 && (_0x36a2xe = _0x36a2x4, _0x36a2x4 = _0x36a2x3[1] || {},
	_0x36a2xc = 2), "object" == typeof _0x36a2x4 || isFunction(_0x36a2x4) || (_0x36a2x4 = {}); _0x36a2xd > _0x36a2xc; ++_0x36a2xc) {
		if (null != (a = _0x36a2x3[_0x36a2xc])) {
			for (var b in a) {
				var c = _0x36a2x4[b],
				_0x36a2x12 = a[b];
				_0x36a2x4 !== _0x36a2x12 && (_0x36a2xe && _0x36a2x12 && "object" == typeof _0x36a2x12 && !_0x36a2x12["nodeType"] ? _0x36a2x4[b] = extend(_0x36a2xe, c || (null != _0x36a2x12["length"] ? [] : {}), _0x36a2x12) : void(0) !== _0x36a2x12 && (_0x36a2x4[b] = _0x36a2x12))
			}
		}
	};
	return _0x36a2x4
}
function o2q(b) {
	var c = [],
	_0x36a2x4 = function (a) {
		try {
			return encodeURIComponent(a)
		} catch(c) {
			return a
		}
	};
	for (var d in b) {
		var e = b[d];
		if (null != e && !isFunction(e)) {
			if (isArray(e)) {
				for (var f = 0, _0x36a2x10 = 0, _0x36a2x11 = e["length"]; _0x36a2x11 > f; ++f) {
					null == e[f] || isFunction(e[f]) || (c["push"](_0x36a2x4(d) + "[" + _0x36a2x10 + "]=" + _0x36a2x4(e[f])), ++_0x36a2x10)
				}
			} else {
				c["push"](_0x36a2x4(d) + "=" + _0x36a2x4(e))
			}
		}
	};
	return c["join"]("&")
}
function randString(a, b) {
	var c = "";
	b = b || "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	for (var d = a; d > 0; --d) {
		c += b[Math["round"](Math["random"]() * (b["length"] - 1))]
	};
	return c
}
function inIframe() {
	try {
		return ! (window["self"] == window["top"])
	} catch(e) {
		return ! 1
	}
}
function psr(a) {
	return "https:" != location["protocol"] ? a: (a = a["replace"](/http:\/\/(cs(\d+)\.vk\.me\/c(\d+)\/)/gi, "https://"), a = a["replace"](/http:\/\/cs(\d+)\.(userapi\.com|vk\.com|vk\.me|vkontakte\.ru)\/c(\d+)\/(v\d+\/|[a-z0-9\/_:\-]+\.jpg)/gi, "https://pp.vk.me/c/"), a = a["replace"](/http:\/\/cs(\d+)\.(userapi\.com|vk\.com|vk\.me|vkontakte\.ru)\/([a-z0-9\/_:\-]+\.jpg)/gi, "https://pp.vk.me/c/"), a = a["replace"](/http:\/\/cs(\d+)\.(userapi\.com|vk\.com|vk\.me|vkontakte\.ru)\//gi, "https://ps.vk.me/c/"), a = a["replace"](/http:\/\/video(\d+)\.vkadre\.ru\//gi, "https://ps.vk.me/v/"), a = a["replace"](/http:\/\//gi, "https://"))
}
function showVideo(d, e, f, g) {
	if (e["files"]) {
		pxvk(e);
	}
	return ! 0
}
function getVideo(c, d, e, f, g) {
	Ajax["api"]("video.get", {
		access_token: d["access_token"],
		v: "5.44",
		videos: d["video"],
		//sig: d["sig"]
	},
	function (a) {
		if (re(document["getElementById"]("load")), a["response"]) {
			if (a["response"]["items"]["length"] > 0) {
				var b = a["response"]["items"][0];
				if (e["setItem"](f, b, {
					expirationSliding: 86400
				}), "", b && b["files"]) {
					return showVideo(c, b, d, 1)
				};
				/vk\.com\/video_ext\.php/i ["test"](b["player"].toString()) ? (
				g ? (ip_h = g["ip_h"], getVideo(c, g, e, f)) : (e["setItem"](f, a, {
					expirationSliding: 60
				}), re(document["getElementById"]("loader")), c["innerHTML"] = "<div class=\"alan\"><div class=\"mesaj\">Embed video not found and can not be played</div></div>")) : c["innerHTML"] = "<iframe preventhide=\"0\" scrolling=\"no\" width=\"100%\" height=\"100%\" style=\"overflow: hidden;\" src=\"" + b["player"] + "\" frameborder=\"0\" allowfullscreen=\"true\" webkitallowfullscreen=\"true\" mozallowfullscreen=\"true\"></iframe>"
			} else {
				g ? (ip_h = g["ip_h"], getVideo(c, g, e, f)) : (e["setItem"](f, a, {
					expirationSliding: 60
				}), re(document["getElementById"]("loader")), c["innerHTML"] = "<div class=\"alan\"><div class=\"mesaj\">Embed video not found and can not be played</div></div>")
			}
		} else {
			e["setItem"](f, a, {
				expirationSliding: 60
			}),
			attempts > 0 ? (attempts--) : (c["innerHTML"] = "<div class=\"alan\"><div class=\"mesaj\"><a id=\"reload_href\">Reload Page</a></div></div>", window["addEvent"](document["getElementById"]("reload_href"), "click", function () {
				get(c, ajaxParams)
			}))
		}
	})
}
function get(a, b, c) {
		if (window["postMessage"]) {
			var d = new Cache( - 1, !1, new Cache.LocalStorageCacheStorage),
			_0x36a2xd = ip_h + "_px_" + b["video"],
			_0x36a2xe = d["getItem"](_0x36a2xd);
			window["is_dev"] && (_0x36a2xe = null);
			try {
				return showVideo(a, _0x36a2xe, b, 0)
			} catch(s) {
				getVideo(a, b, d, _0x36a2xd, c)
			}
		} else {
			re(document["getElementById"]("loader")),
			a["innerHTML"] = "<div class=\"alan\"><div class=\"mesaj\">Your browser is old and don't support some features</div></div>"
		}
}
var parseJSON = window["JSON"] && JSON["parse"] ?
function (a) {
	try {
		return JSON["parse"](a)
	} catch(e) {
		return console["log"](e),
		eval("(" + a + ")")
	}
}: function (a) {
	return eval("(" + a + ")")
}; !
function (h) {
	function _0x36a2x3() {
		var a = "";
		for (i = 0; i < 5; i++) {
			a += Math["ceil"](15 * Math["random"]()).toString(16)
		};
		return a
	}
	function _0x36a2x4(a, b, c, d, e) {
		a[b] ? c["apply"](d) : (e = e || 0, 1e3 > e && setTimeout(function () {
			_0x36a2x4(a, b, c, d, e + 1)
		},
		0))
	}
	function _0x36a2xc(a, b) {
		switch (typeof a) {
		case "string":
			return b ? a["replace"](/&/g, "&amp;")["replace"](/</g, "&lt;")["replace"](/>/g, "&gt;")["replace"](/"/g, "&quot;")["replace"](/'/g, "&#039;") : a["replace"](/&#039;/g, "'")["replace"](/&quot;/g, "\"")["replace"](/&gt;/g, ">")["replace"](/&lt;/g, "<")["replace"](/&amp;/g, "&");
		case "object":
			if ("[object Array]" === Object["prototype"]["toString"]["apply"](a)) {
				newValue = [];
				for (var c = 0; c < a["length"]; c++) {
					newValue[c] = _0x36a2xc(a[c], b)
				}
			} else {
				for (var d in a) {
					newValue = {},
					Object["hasOwnProperty"]["call"](a, d) && (newValue[d] = _0x36a2xc(a[d], b))
				}
			};
		default:
			newValue = a
		};
		return newValue
	}
	function _0x36a2xd(a, b) {
		_0x36a2x1a["loaded"] ? a["apply"](b, [_0x36a2x1a]) : _0x36a2x2d["push"]([b, a])
	}
	function _0x36a2x10() {
		_0x36a2x1a["loaded"] = !0;
		for (var a = _0x36a2x2d["length"]; a--;) {
			_0x36a2x2d[a][1]["apply"](_0x36a2x2d[a][0], [_0x36a2x1a])
		}
	}
	function _0x36a2x11(f, g) {
		_0x36a2xd(function (b) {
			var c = JSON["parse"](f);
			if (c[0]) {
				c[1] || (c[1] = []);
				for (var d = c[1]["length"]; d--;) {
					if (c[1][d]["_func"]) {
						var e = c[1][d]["_func"];
						c[1][d] = function () {
							var a = Array["prototype"]["slice"]["call"](arguments);
							a["unshift"]("_func" + e),
							g["callMethod"]["apply"](g, a)
						}
					} else {
						g["options"]["safe"] && (c[1][d] = _0x36a2xc(c[1][d], !0))
					}
				};
				setTimeout(function () {
					if (!g["methods"][c[0]]) {
						throw Error("fastXDM: Method " + c[0] + " is undefined")
					};
					g["methods"][c[0]]["apply"](g, c[1])
				},
				0)
			}
		})
	}
	function _0x36a2x12(a, b) {
		for (var c in b) {
			a[c] && "object" == typeof a[c] ? _0x36a2x12(a[c], b[c]) : a[c] = b[c]
		}
	}
	var j = {},
	_0x36a2x2d = [],
	_0x36a2x1a = {};
	h["fastXDM"] = {
		_id: 0,
		Server: function (a, b, c) {
			this["methods"] = a || {},
			this["id"] = h["fastXDM"]["_id"]++,
			this["options"] = c || {},
			this["filter"] = b,
			this["key"] = _0x36a2x3(),
			this["methods"]["%init%"] = this["methods"]["__fxdm_i"] = function () {
				h["fastXDM"]["run"](this["id"]),
				this["methods"]["onInit"] && this["methods"]["onInit"]()
			},
			this["frameName"] = "fXD" + this["key"],
			this["server"] = !0,
			j[this["key"]] = [_0x36a2x11, this]
		},
		Client: function (c, d) {
			if (this["methods"] = c || {},
			this["id"] = h["fastXDM"]["_id"]++, this["options"] = d || {},
			h["fastXDM"]["run"](this["id"]), 0 !== window["name"]["indexOf"]("fXD")) {
				throw Error("Wrong window.name property.")
			};
			this["key"] = window["name"]["substr"](3),
			this["caller"] = window["parent"],
			j[this["key"]] = [_0x36a2x11, this],
			this["client"] = !0,
			h["fastXDM"]["on"]("helper", function () {
				h["fastXDM"]["onClientStart"](this)
			},
			this),
			_0x36a2xd(function (a) {
				a["send"](this, JSON["stringify"](["%init%"]));
				var b = this["methods"];
				setTimeout(function () {
					b["onInit"] && b["onInit"]()
				},
				0)
			},
			this)
		},
		onMessage: function (a) {
			if (!a["data"]) {
				return ! 1
			};
			var b = a["data"];
			if ("string" != typeof b && !(b instanceof String)) {
				return ! 1
			};
			var c = b["substr"](0, 5);
			if (j[c]) {
				var d = j[c][1]; ! d || d["filter"] && !d["filter"](a["origin"]) || j[c][0](a["data"]["substr"](6), d)
			}
		},
		_q: {},
		on: function (a, b, c) {
			this["_q"][a] || (this["_q"][a] = []),
			-1 == this["_q"][a] ? b["apply"](c) : this["_q"][a]["push"]([b, c])
		},
		run: function (a) {
			var b = (this["_q"][a] || [])["length"];
			if (this["_q"][a] && b > 0) {
				for (var c = 0; b > c; c++) {
					this["_q"][a][c][0]["apply"](this["_q"][a][c][1])
				}
			};
			this["_q"][a] = -1
		},
		waitFor: _0x36a2x4
	},
	h["fastXDM"]["Server"]["prototype"]["start"] = function (a, b) {
		if (a["contentWindow"]) {
			this["caller"] = a["contentWindow"],
			this["frame"] = a,
			h["fastXDM"]["on"]("helper", function () {
				h["fastXDM"]["onServerStart"](this)
			},
			this)
		} else {
			var c = this;
			b = b || 0,
			50 > b && setTimeout(function () {
				c["start"]["apply"](c, [a, b + 1])
			},
			100)
		}
	},
	h["fastXDM"]["Server"]["prototype"]["destroy"] = function () {
		j["splice"](j["indexOf"](this["key"]), 1)
	},
	h["fastXDM"]["Server"]["prototype"]["append"] = function (a, b) {
		var c = document["createElement"]("DIV");
		c["innerHTML"] = "<iframe name=\"" + this["frameName"] + "\" ></iframe>";
		var d = c["firstChild"],
		_0x36a2xd = this;
		return setTimeout(function () {
			d["frameBorder"] = "0",
			b && _0x36a2x12(d, b),
			a["insertBefore"](d, a["firstChild"]),
			_0x36a2xd["start"](d)
		},
		0),
		d
	},
	h["fastXDM"]["Client"]["prototype"]["callMethod"] = h["fastXDM"]["Server"]["prototype"]["callMethod"] = function () {
		for (var b = Array["prototype"]["slice"]["call"](arguments), _0x36a2xe = b["shift"](), _0x36a2x10 = b["length"]; _0x36a2x10--;) {
			if ("function" == typeof b[_0x36a2x10]) {
				this["funcsCount"] = (this["funcsCount"] || 0) + 1;
				var c = b[_0x36a2x10],
				_0x36a2x12 = "_func" + this["funcsCount"];
				this["methods"][_0x36a2x12] = function () {
					c["apply"](this, arguments),
					delete this["methods"][_0x36a2x12]
				},
				b[_0x36a2x10] = {
					_func: this["funcsCount"]
				}
			} else {
				this["options"]["safe"] && (b[_0x36a2x10] = _0x36a2xc(b[_0x36a2x10], !1))
			}
		};
		_0x36a2x4(this, "caller", function () {
			h["fastXDM"]["on"](this["id"], function () {
				_0x36a2xd(function (a) {
					a["send"](this, JSON["stringify"]([_0x36a2xe, b]))
				},
				this)
			},
			this)
		},
		this)
	},
	_0x36a2x1a["send"] = function (a, b) {
		var c = a["frame"] ? a["frame"]["contentWindow"] : a["caller"];
		c["postMessage"](a["key"] + ":" + b, "*")
	},
	h["addEventListener"] ? h["addEventListener"]("message", h["fastXDM"]["onMessage"], !1) : h["attachEvent"]("onmessage", h["fastXDM"]["onMessage"]),
	_0x36a2x10()
} (window);
var xdReady = !1,
XDM = {
	remote: null,
	init: function () {
		if (this["remote"]) {
			return ! 1
		};
		this["remote"] = new fastXDM.Server({
			onInit: function () {
				xdReady = !0
			}
		});
		var a = document["createElement"]("DIV");
		a["id"] = "dxb_api_transport",
		document["getElementById"]("pusuxplayer")["appendChild"](a),
		this["remote"]["append"](document["getElementById"]("dxb_api_transport"), {
			src: "https://api.vk.com/fxdm_oauth_proxy.html"
		})
	}
},
Ajax = {
	_r: null,
	_x: function () {
		try {
			return new ActiveXObject("Msxml2.XMLHTTP")
		} catch(e) {
			try {
				return new ActiveXObject("Microsoft.XMLHTTP")
			} catch(e) {
				return new XMLHttpRequest
			}
		}
	},
	_events: {
		done: null,
		fail: null
	},
	_send: function (b, c, d, e) {
		var f, _0x36a2xe = null != this["_r"] ? this["_r"] : this._x(),
		_0x36a2x10 = this;
		f = isString(c) ? c: o2q(c);
		try {
			_0x36a2xe["open"]("POST", b, !0)
		} catch(a) {
			return _0x36a2x10["jsonp"](b, c, d, e)
		};
		_0x36a2xe["onreadystatechange"] = function () {
			if (4 == _0x36a2xe["readyState"]) {
				if (_0x36a2xe["status"] >= 200 && _0x36a2xe["status"] < 300) {
					try {
						var a = parseJSON(_0x36a2xe["responseText"])
					} catch(c) {
						var a = _0x36a2xe["responseText"]
					};
					isFunction(d) && d(a, _0x36a2xe)
				} else {
					0 != _0x36a2xe["status"] && isFunction(e) && e(_0x36a2xe["responseText"], _0x36a2xe)
				}
			}
		},
		_0x36a2xe["setRequestHeader"]("Content-type", "application/x-www-form-urlencoded"),
		_0x36a2xe["setRequestHeader"]("X-Requested-With", "XMLHttpRequest"),
		_0x36a2xe["setRequestHeader"]("X-Etag", randString(16)),
		inIframe() && (_0x36a2xe["setRequestHeader"]("X-Iframe-URI", window["_ref"]["uri"]), _0x36a2xe["setRequestHeader"]("X-Iframe-Hash", window["_ref"]["hash"]));
		try {
			_0x36a2xe["send"](f)
		} catch(a) {};
		return _0x36a2xe
	},
	post: function (a, b, c, d) {
		return this._send(a, b, c, d)
	},
	jsonp: function (d, e, f, g) {
		var h = "callbackFn" + timeNow() + "_" + rand(1e4, 9999999);
		void(0) !== window["callbackFn"] && (h = window["callbackFn"]),
		f = isFunction(f) ? f: function () {},
		g = isFunction(g) ? g: function () {};
		var i = function (a) {
			var b = document["getElementById"](a);
			b && b["parentNode"] && b["parentNode"]["removeChild"](b)
		},
		_0x36a2x10 = window["setTimeout"](function () {
			window[h] = null,
			delete window[h],
			i(h),
			g()
		},
		3e5);
		window[h] = function (a) {
			window["clearTimeout"](_0x36a2x10),
			f(a),
			i(h)
		};
		var j = isString(e) ? e: o2q(e);
		j["length"] && (j += "&"),
		j += "callback=" + h;
		var k = function (a, b) {
			var c = document["createElement"](a);
			return b && extend(c, b),
			c
		},
		_0x36a2x2c = k("script", {
			type: "text/javascript",
			async: !0,
			src: d + "?" + j,
			id: h
		});
		document["getElementsByTagName"]("head")[0]["appendChild"](_0x36a2x2c)
	},
	api: function (b, c, d) {
		var e, _0x36a2xd = c || {};
		e = qsEncode(_0x36a2xd),
		xdReady ? XDM["remote"]["callMethod"]("apiCall", b, e, function (a) {
			d(a)
		}) : (XDM["init"](), setTimeout(function () {
			Ajax["api"](b, c, d)
		},
		50))
	}
},
attempts = 3