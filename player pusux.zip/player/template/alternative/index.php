<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
if($data["platform"]=="drive")
{
	require( get_home_directory() . '/template/alternative/drive/index.php' );
}
elseif($data["platform"]=="ok")
{
	require( get_home_directory() . '/template/alternative/ok/index.php' );
}
elseif($data["platform"]=="mail")
{
	require( get_home_directory() . '/template/alternative/mail/index.php' );
}
elseif($data["platform"]=="vk")
{
	require( get_home_directory() . '/template/alternative/vk/index.php' );
}
else
{
	echo "alternatif çözüm bulunamadı";
}
?>