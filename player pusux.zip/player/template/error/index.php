<?php /*b78060ea9121f5151d27d9cf8fdc7b0f*/ ?>
<?php @header('HTTP/1.0 404 Not Found', true, 404); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>404 Not Found - Pusux Player <?=$ayar["vercion"]?></title>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
	<style type="text/css">html,body{margin:0px;padding:0px;height: 100% !important;}#player{z-index:1;position:absolute;width: 100% !important;height: 100% !important;}a{cursor:pointer}#type{opacity:0;position:fixed;top:5px;left:10px;overflow:hidden;z-index:999999999;/* display:none; */-webkit-transition: opacity 1s ease-in-out;-moz-transition: opactiy 1s ease-in-out;-ms-transition: opacity 1s ease-in-out;-o-transition: opacity 1s ease-in-out;transition: opacity 1s ease-in-out;}.mesaj{margin:0 auto;position: relative;width: 500px;color:#fff;font-size:30px;text-align:center;display: table-cell;vertical-align: middle;}.alan{position:relative;display: table;width:100%;height:100%;}body:hover>#type{opacity:1;-webkit-transition: opacity 0.05s ease-in-out;-moz-transition: opactiy 0.05s ease-in-out;-ms-transition: opacity 0.05s ease-in-out;-o-transition: opacity 0.05s ease-in-out;transition: opacity 0.05s ease-in-out;}</style>
</head>
<body bgcolor="#000000">
	<div class="alan">
		<div class="mesaj">Video Bulunamadı.</div>
	</div>
	<?=stripcslashes($ayar["htmlcode"])?>
	<!--pusux.com Pusux Player Vercion <?=$ayar["vercion"]?>-->
</body>
</html>
