<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
	$data = (object)$data;
	$jwdata = (object)$data->jwdata;
	$stream = $data->stream;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>Pusux Player <?=$ayar["vercion"]?></title>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="<?=get_home_url()?>/template/jwplayer/jw-player/jwplayer.js"></script>
	<script type="text/javascript">jwplayer.key="<?=$jwdata->jw_licence?>";</script>
	<style type="text/css">html,body{margin:0px;padding:0px;height: 100% !important;}#pusuxplayer{z-index:1;position:absolute;width: 100% !important;height: 100% !important;}a{cursor:pointer}#type{opacity:0;position:fixed;top:5px;left:10px;/* overflow:hidden; */z-index:999999999;/* display:none; */-webkit-transition: opacity 1s ease-in-out;-moz-transition: opactiy 1s ease-in-out;-ms-transition: opacity 1s ease-in-out;-o-transition: opacity 1s ease-in-out;transition: opacity 1s ease-in-out;}.mesaj{margin:0 auto;position: relative;width: 500px;color:#fff;font-size:30px;text-align:center;display: table-cell;vertical-align: middle;}.alan{position:relative;display: table;width:100%;height:100%;}body:hover>#type{opacity:1;-webkit-transition: opacity 0.05s ease-in-out;-moz-transition: opactiy 0.05s ease-in-out;-ms-transition: opacity 0.05s ease-in-out;-o-transition: opacity 0.05s ease-in-out;transition: opacity 0.05s ease-in-out;}#down{position:relative;}#down:hover>.down-list{display:block;}.down-list{display:none;position: absolute;list-style: none;float: left;left: 3px;top: 32px;z-index: 9999999999999999;background: #2BBECF;margin: 0;border-radius: 3px;width: 144px;padding: 0;padding-top: 6px;}#type a,#type div{float:left;}.down-list li{float: left;width: 134px;padding: 5px;}.down-list li:hover{background:#fff;}.down-list li:hover>a{color:#2BBECF}.down-list li a{text-align: center;color: #EBEBEB;text-decoration: none;width: 100%;}.down-list li:last-child{border-radius:0 0 3px 3px;}</style>
</head>
<body bgcolor="#000000">
<div id="type">
	<?php player_mode_button($data); ?>
	<?php player_download_button($stream); ?>
</div>
<div id="pusuxplayer"></div>
	<script type="text/javascript">
        jwplayer("pusuxplayer").setup({
            id: "pusuxplayer",
            playlist: [{
            sources: [
			<?php 
			$i = count($stream);
			foreach($stream as $player)
			{
			?>
				{
					"file":"<?=preg_replace('@"@si','%22',$player['kalip'])?>", 
					"label":"<?=$player['tur']?>", 
					"type": "mp4",
					<?php if($player['tur']=="480p" or ($i==2 and $player['tur']=="720p")){ ?>
					"default": "true"
					<?php } ?>
				},
			<?php
				$i++;
			}
			?>	
			
			],
			<?php 
			if(!empty($data->subtitle))
			{
			?>
			tracks: [{ 
				file: "<?=get_home_url()?>/altyazi.php?ay=<?=urlencode($data->subtitle)?>", 
				label: "Türkçe",
				kind: "captions",
				"default": true 
			}],
			captions: {
				color: '#FFFFFF',
				backgroundOpacity: 0,
				fontSize: 25,
				edgeStyle: 'uniform'
			},
			<?php
			}
			?>	
			<?php 
			if(!empty($jwdata->jw_background))
			{
			?>
			image: "<?=$jwdata->jw_background?>",
			<?php
			}
			?>
            }],
			<?php 
			if(!empty($jwdata->jw_logo))
			{
			?>
			logo: {
				file: '<?=$jwdata->jw_logo?>',
				link: '<?=$jwdata->jw_logourl?>'
			},
			<?php
			}
			?>
            modes: [
                { type: "flash", src: "<?=get_home_url()?>/template/jwplayer/jw-player/jwplayer.flash.swf" },
                { type: "html5" }
            ],
            abouttext: "PusuX Player",
            aboutlink: "http://www.pusux.com/",
            startparam: "start",
            provider: "http",
			fallback: "false",
			<?php 
			if(!empty($jwdata->jw_theme))
			{
			?>
			skin: "<?=$jwdata->jw_theme?>",
			<?php
			}
			?>
			primary: '<?=get_player_mode($data)?>',
			width:"100%",
			height:"100%",
			mute: false,
			autostart: "<?php echo ($jwdata->jw_autostart == 0) ? 'false' : 'true'; ?>",
			<?php 
			if(!empty($data->subtitle))
			{
			?>
			captions: {
				color: '#FFFFFF',
				backgroundOpacity: 0,
				fontSize: 25,
				edgeStyle: 'uniform'
			}
			<?php
			}
			?>	
        });	
		<?php if($jwdata->jw_session!=0){ ?>
		var filmid = "<?php echo (isset($_GET['v'])) ? $_GET['v'] : $_GET['i']; ?>"; 
		jwplayer("pusuxplayer").onTime(function (e) {
			localStorage.setItem('px_' + filmid, e.position);
		});
		jwplayer("pusuxplayer").onComplete(function () {
			localStorage.removeItem('px_' + filmid);
		})
		var position = localStorage.getItem('px_' + filmid);
		if (position != null) {
			jwplayer("pusuxplayer").onBeforePlay(function () {
				jwplayer("pusuxplayer").seek(position);
			})
		}
		<?php } ?>
		jwplayer("pusuxplayer").onBeforePlay(function(){ jwplayer("pusuxplayer").setVolume(100); });
    </script>
	<?=stripcslashes($ayar["htmlcode"])?>
</body>
</html>
