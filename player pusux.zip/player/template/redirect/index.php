<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
	$url = $data["url"];
	go_redirect($url);
?>