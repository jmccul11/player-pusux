<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
include('./index.php');

if(strpos(@$_SERVER["HTTP_REFERER"], $_SERVER["SERVER_NAME"]) === false) exit;
	
	define("SRT_STATE_SUBNUMBER", 0);
	define("SRT_STATE_TIME",      1);
	define("SRT_STATE_TEXT",      2);
	define("SRT_STATE_BLANK",     3);
	
	function ParseSrt($File)
	{
		$Lines = file($File);
		
		$Subtitles = array();
		$State = SRT_STATE_SUBNUMBER;
		$SubNum = 0;
		$SubText = "";
		$SubTime = "";
		
		foreach($Lines as $Line) {
			switch($State) {
				case SRT_STATE_SUBNUMBER:
				$SubNum = trim($Line);
				$State  = SRT_STATE_TIME;
				break;
				
				case SRT_STATE_TIME:
				$SubTime = trim($Line);
				$State   = SRT_STATE_TEXT;
				break;
				
				case SRT_STATE_TEXT:
				if (trim($Line) == "") 
				{
					$Subtitle = array();
					$Subtitle[0] = $SubNum;
					list($Subtitle[1], $Subtitle[2]) = explode(" --> ", $SubTime);
					
					$Subtitle[1] = explode(",", $Subtitle[1]);
					$Subtitle[1] = strtotime("1970-01-01 ".$Subtitle[1][0]." UTC").".".$Subtitle[1][1];
					
					$Subtitle[2] = explode(",", $Subtitle[2]);
					$Subtitle[2] = strtotime("1970-01-01 ".$Subtitle[2][0]." UTC").".".$Subtitle[2][1];
					
					$Subtitle[3] = $SubText;
					$SubText = "";
					$State = SRT_STATE_SUBNUMBER;
					
					$Subtitles[] = $Subtitle;
				} 
				else 
				{
					$SubText .= $Line;
				}
				break;
			}
		}
		
		return $Subtitles;
	}
	
	function rc4($key, $str) {
		$s = array();
		for ($i = 0; $i < 256; $i++) {
			$s[$i] = $i;
		}
		$j = 0;
		for ($i = 0; $i < 256; $i++) {
			$j = ($j + $s[$i] + ord($key[$i % strlen($key)])) % 256;
			$x = $s[$i];
			$s[$i] = $s[$j];
			$s[$j] = $x;
		}
		$i = 0;
		$j = 0;
		$res = '';
		for ($y = 0; $y < strlen($str); $y++) {
			$i = ($i + 1) % 256;
			$j = ($j + $s[$i]) % 256;
			$x = $s[$i];
			$s[$i] = $s[$j];
			$s[$j] = $x;
			$res .= $str[$y] ^ chr($s[($s[$i] + $s[$j]) % 256]);
		}
		return $res;
	}
	
	
	$Data = @$_GET["Data"];
	$JData = json_decode(base64_decode($Data), true);
	
	$VideoSources = @$JData["VideoSources"];
	$Subtitle = @$JData["Subtitle"];
	
	$SrtArray = ParseSrt("subtitles/".$Subtitle);
	
	$JSON = json_encode($SrtArray);
	$Encoded = rc4($VideoSources[0]["file"], $JSON);
	$Last = base64_encode($Encoded);
?>		