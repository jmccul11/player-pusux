
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Tablo için tablo yapısı `ayarlar`
--

CREATE TABLE IF NOT EXISTS `ayarlar` (
  `id` int(3) NOT NULL auto_increment,
  `bolum` varchar(100) character set utf8 collate utf8_turkish_ci NOT NULL,
  `deger` text character set utf8 collate utf8_turkish_ci,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=123 ;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `bolum`, `deger`) VALUES
(66, 'url', 'http://pusux.com/pusuxplayertest/'),
(67, 'jw_theme', 'vapor'),
(68, 'jw_background', 'http://pusux.com/pusuxplayer/img/resim.jpg'),
(69, 'jw_logo', 'http://pusux.com/pusuxplayer/img/jwlogo.png'),
(70, 'jw_logourl', 'http://pusux.com'),
(76, 'hotlink_status', '0'),
(77, 'hotlink_domain', 'localhost,pusux.com'),
(78, 'hotlink_redirect', 'http://www.pusux.com/'),
(79, 'iframe_width', '600'),
(80, 'iframe_height', '400'),
(82, 'jw_licence', 'nIGxdKhS1Lub4lgHils8JexPpJmCRe+2Z1vBww=='),
(83, 'jw_mobile_mode', 'html5'),
(84, 'jw_autostart', '0'),
(85, 'jw_session', '0'),
(88, 'vercion', '3.2'),
(89, 'platform_plus', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"html5";}'),
(91, 'platform_drive', 'a:2:{s:6:"status";s:1:"5";s:4:"mode";s:5:"html5";}'),
(93, 'platform_ok', 'a:2:{s:6:"status";s:1:"5";s:4:"mode";s:5:"html5";}'),
(95, 'platform_vimeo', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"html5";}'),
(97, 'platform_openload', 'a:2:{s:6:"status";s:1:"1";s:4:"mode";s:5:"html5";}'),
(99, 'platform_vidme', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"html5";}'),
(101, 'platform_myvideo', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"html5";}'),
(103, 'platform_youtube', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"html5";}'),
(105, 'platform_onedrivelive', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"html5";}'),
(107, 'platform_mail', 'a:2:{s:6:"status";s:1:"5";s:4:"mode";s:5:"html5";}'),
(112, 'platform_vk', 'a:5:{s:6:"status";s:1:"5";s:4:"mode";s:5:"html5";s:11:"tokenuptime";i:0;s:10:"PX_VK_MAIL";s:0:"";s:10:"PX_VK_PASS";s:0:"";}'),
(113, 'platform_vidag', 'a:2:{s:6:"status";s:1:"1";s:4:"mode";s:5:"html5";}'),
(114, 'platform_videoraj', 'a:2:{s:6:"status";s:1:"1";s:4:"mode";s:5:"html5";}'),
(115, 'platform_uptostream', 'a:2:{s:6:"status";s:1:"1";s:4:"mode";s:5:"html5";}'),
(116, 'platform_mp4stream', 'a:2:{s:6:"status";s:1:"2";s:4:"mode";s:5:"html5";}'),
(117, 'platform_picasa', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"html5";}'),
(118, 'language', 'tr'),
(119, 'htmlcode', ''),
(120, 'jw_button', 'a:2:{s:4:"mode";s:1:"1";s:8:"download";s:1:"0";}'),
(121, 'platform_facebook', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"flash";}'),
(122, 'platform_photos', 'a:2:{s:6:"status";s:1:"3";s:4:"mode";s:5:"flash";}');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `broken_link`
--

CREATE TABLE IF NOT EXISTS `broken_link` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `type` varchar(50) NOT NULL,
  `get_data` text NOT NULL,
  `classic` text,
  `reg_id` int(11) default NULL,
  `status` int(11) NOT NULL,
  `referer` text,
  `time` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `movie`
--

CREATE TABLE IF NOT EXISTS `movie` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `code` varchar(200) default NULL,
  `platform` varchar(200) NOT NULL,
  `url` text NOT NULL,
  `url_data` text NOT NULL,
  `subtitle` text,
  `owner` text NOT NULL,
  `title` varchar(300) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) NOT NULL auto_increment,
  `user_name` varchar(30) character set utf8 collate utf8_turkish_ci NOT NULL,
  `user_password` varchar(33) character set utf8 collate utf8_turkish_ci NOT NULL,
  `user_session` varchar(32) character set utf8 collate utf8_turkish_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `user`
--

INSERT INTO `user` (`id`, `user_name`, `user_password`, `user_session`) VALUES
(1, 'admin', '14e1b600b1fd579f47433b88e8d85291', '8c5aad4ce2eaab7148f24459aaf75330');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `vk_token`
--

CREATE TABLE IF NOT EXISTS `vk_token` (
  `id` int(3) NOT NULL auto_increment,
  `user` varchar(100) character set utf8 collate utf8_turkish_ci NOT NULL,
  `token` text character set utf8 collate utf8_turkish_ci,
  `date` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;
