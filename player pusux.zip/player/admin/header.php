<?php /*b78060ea9121f5151d27d9cf8fdc7b0f*/ ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?=px_tr("Pusux Player Yönetim Paneli")?></title>
        <link type="text/css" href="<?=get_home_url()?>admin/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="<?=get_home_url()?>admin/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="<?=get_home_url()?>admin/css/theme.css" rel="stylesheet">
        <link type="text/css" href="<?=get_home_url()?>admin/images/icons/css/font-awesome.css" rel="stylesheet">
        <!--<link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>-->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script type='text/javascript'>//<![CDATA[
		$(window).load(function(){
		$("[data-toggle='tooltip']").tooltip();

		});//]]> 
		</script>
    </head>
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a><a class="brand" href="<?=get_home_url()?>admin/index.html"><?=px_tr("Pusux Player Yönetim Paneli")?></a>
                    <div class="nav-collapse collapse navbar-inverse-collapse">
                        
                        
                        <ul class="nav pull-right">
                            <li><a href="<?=get_home_url()?>admin/kullanici.html"><?=px_tr("Kullanıcı Bilgileri")?></a></li>
							<li class="nav-user dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <!--<img src="images/user.png" class="nav-avatar" />-->
								<i class="icon-user" style="font-size: 35px;"></i>
                                <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="http://www.pusux.com/destek"><?=px_tr("Destek")?></a></li>
									<li><a href="http://www.pusux.com">Pusux.Com</a></li>
                                    <li class="divider"></li>
                                    <li><a href="<?=get_home_url()?>admin/logout.html"><?=px_tr("Çıkış Yap")?></a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- /.nav-collapse -->
                </div>
            </div>
            <!-- /navbar-inner -->
        </div>
        <!-- /navbar -->
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="span3">
                        <div class="sidebar">
                            <ul class="widget widget-menu unstyled">
                                <li class="active">
									<a href="<?=get_home_url()?>admin/"><i class="menu-icon icon-dashboard"></i><?=px_tr("Kontrol Paneli")?></a>
								</li>
								<li>
									<a href="<?=get_home_url()?>admin/ayarlar.html"><i class="menu-icon icon-cog"></i><?=px_tr("Ayarlar")?></a>
								</li>
								<li>
									<a href="<?=get_home_url()?>admin/olustur.html"><i class="menu-icon icon-paste"></i><?=px_tr("Bağlantı Oluştur")?></a>
								</li>
                                <li>
									<a href="<?=get_home_url()?>admin/linkler.html"><i class="menu-icon icon-film"></i><?=px_tr("Bağlantılar")?>
										<b class="label green pull-right">
											<?=$db->get_var("select count(id) from movie");?>
										</b>
									</a>
								</li>
                                <li>
									<a href="<?=get_home_url()?>admin/kirik-linkler.html">
										<i class="menu-icon icon-trash"></i>
										<?=px_tr("Kırık Bağlantılar")?>
										<b class="label orange pull-right">
											<?=$db->get_var("select count(id) from broken_link where status=1");?>
										</b>
									</a>
								</li>
								<li>
									<a href="<?=get_home_url()?>admin/moduller.html"><i class="menu-icon icon-cogs"></i><?=px_tr("Ek Modüller")?></a>
								</li>
								<!--<li>
									<a href="<?=get_home_url()?>admin/reklam.html"><i class="menu-icon icon-bar-chart"></i><?=px_tr("Reklam Modülü")?></a>
								</li>-->
                            </ul>
                            <!--/.widget-nav-->
                        </div>
                        <!--/.sidebar-->
                    </div>