<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
require("../inc/platform_generate_data/platform_generate_data.php");
require("./languages/translation.php");
/*çoklu dil desteği*/
$tr = new translation_pusux($ayar["language"]);
function px_tr($text)
{
	global $tr;
	$list = $tr->translation_list;
	if(isset($list[$text]))
		$text = $list[$text];
	return $text;
}
/*değişken ve fonksiyonlar*/
$message = array();
$platform_list = array(
	"platform_mp4stream" => array("text" => "Mp4 Oynatıcı", "type" => array("jwplayer")),
	"platform_picasa" => array("text" => "Google Picasa", "type" => array("jwplayer","redirect")),
	"platform_plus" => array("text" => "Google Plus", "type" => array("jwplayer","redirect")),
	"platform_drive" => array("text" => "Google Drive", "type" => array("jwplayer","alternative","redirect")),
	"platform_photos" => array("text" => "Google Photos", "type" => array("jwplayer","redirect")),
	"platform_youtube" => array("text" => "Youtube", "type" => array("jwplayer","redirect")),
	"platform_ok" => array("text" => "Ok.ru", "type" => array("alternative","redirect")),
	"platform_vk" => array("text" => "Vk.com", "type" => array("alternative","redirect")),
	"platform_vimeo" => array("text" => "Vimeo", "type" => array("jwplayer","redirect")),
	"platform_mail" => array("text" => "Mail.ru", "type" => array("alternative","redirect")),
	"platform_vidme" => array("text" => "Vid.me", "type" => array("jwplayer","redirect")),
	"platform_myvideo" => array("text" => "Myvideo.az", "type" => array("jwplayer","redirect")),
	"platform_onedrivelive" => array("text" => "Onedrive.Live.com", "type" => array("jwplayer","redirect")),
	"platform_openload" => array("text" => "Openload", "type" => array("redirect")),
	"platform_vidag" => array("text" => "Vid.ag", "type" => array("redirect")),
	"platform_videoraj" => array("text" => "Videoraj.to", "type" => array("redirect")),
	"platform_uptostream" => array("text" => "Uptostream", "type" => array("redirect")),
	"platform_facebook" => array("text" => "Facebook.com", "type" => array("jwplayer","redirect")),
);
function get_login_status()
{
	global $message;
	if(isset($_POST["user_name"]) and isset($_POST["user_password"]))
	{
		if(empty($_POST["user_name"]) or empty($_POST["user_password"]))
		{
			$msg["type"] = "0";
			$msg["message"] = px_tr("Lütfen Boş Alan Bırakmayınız.");
			if(count($message)==0)
				$message[] = $msg;
			return false;
		}
		if(create_login_session($_POST["user_name"],$_POST["user_password"]))
			return true;
		else 
			return false;
	}else{
		if(get_login_session())
			return true;
		else 
			return false;
	}
}
function create_login_session($user,$password)
{
	global $db;
	global $message;
	$password = md5(md5($db->escape($password)));
	$user = $db->escape($user);
	$user_session = $db->get_var("select user_session from user where user_name='".$user."' and user_password='".$password."'");
	if(!$user_session)
	{
		$msg["type"] = "0";
		$msg["message"] = px_tr("Kullanıcı adı veya şifre hatalı.");
		if(count($message)==0)
			$message[] = $msg;
		return false;
	}
	else 
	{
		$user_session = md5(md5($user.$password)); 
		$db->query("UPDATE user SET user_session='$user_session' where user_name='".$user."' and user_password='".$password."'");
		$_SESSION["login"] = $user_session;
		$_SESSION["user"] = $user;
		return true;
	}
}
function get_login_session()
{
	global $db;
	if(isset($_SESSION["login"]) and !empty($_SESSION["login"]))
	{
		$login = $db->escape($_SESSION["login"]);
	}
	else 
		return false;
	$user_session = $db->get_var("select user_session from user where user_session='".$login."'");
	if(!$user_session)
		return false;
	else 
		return true;
}
function platform_form_data($platform)
{
	$platform = unserialize($platform);
	if($platform["status"]=="1" or $platform["status"]=="3" or $platform["status"]=="5")
		$bad = "1";
	else 
		$bad = "0";
	if($platform["status"]=="0" or $platform["status"]=="1")
		$status = "redirect";
	elseif($platform["status"]=="2" or $platform["status"]=="3")
		$status = "jwplayer";
	else 
		$status = "alternative";
	
	$data["mode"] = $platform["mode"];
	$data["bad"] = $bad;
	$data["status"] = $status;
	return $data;
}
function platform_form_data_generate($data)
{
	$platform = array();
	if($data["status"]=="redirect")
	{
		if($data["bad"]=="1")
			$platform["status"] = "1";
		else 
			$platform["status"] = "0";
	}elseif($data["status"]=="jwplayer")
	{
		if($data["bad"]=="1")
			$platform["status"] = "3";
		else 
			$platform["status"] = "2";
	}elseif($data["status"]=="alternative")
	{
		if($data["bad"]=="1")
			$platform["status"] = "5";
		else 
			$platform["status"] = "4";
	}
	$platform["mode"] = $data["mode"];
	return serialize($platform);
}
function admin_option_save()
{
	global $ayar;
	global $platform_list;
	global $message;
	global $db;
	if(isset($_POST["option_save"]) and !empty($_POST["option_save"]))
	{
		foreach($_POST as $key=>$value)
		{
			if(isset($platform_list[$key]))
			{
				if($key=="platform_vk")
				{
					$pf = unserialize($ayar["platform_vk"]);
					$vkdata = array();
					$vkdata["tokenuptime"] = @$pf["tokenuptime"];
					$vkdata["PX_VK_MAIL"] = (isset($_POST["PX_VK_MAIL"])) ? $_POST["PX_VK_MAIL"] : @$pf["PX_VK_MAIL"];
					$vkdata["PX_VK_PASS"] = (isset($_POST["PX_VK_PASS"])) ? $_POST["PX_VK_PASS"] : @$pf["PX_VK_PASS"];
				}
				$value = platform_form_data_generate($value);
				update_option($key,$value);
				if($key=="platform_vk")
				{
					$value = unserialize($value);
					$value = $value + $vkdata;
					$value = serialize($value);
					update_option($key,$value);
				}
				$ayar[$key] = $value;
			}else{
				
				if($key=="jw_button")
				{
					$value = serialize($value);
				}else{
					$value = $db->escape($value);
				}
				update_option($key,$value);
				$ayar[$key] = $value;
			}
		}
		$msg["type"] = "1";
		$msg["message"] = px_tr("Ayarlar başarıyla kaydedilmiştir.");
		$message[] = $msg;
		option_save_json();
	}
}
function platform_url_create()
{
	global $message;
	global $ayar;
	global $db;
	if(isset($_POST["generate_url"]))
	{
		if(isset($_POST["platform_url"]) and !empty($_POST["platform_url"]))
		{
			$platform_data = new platform_generate_data();
			$data = $platform_data->get_data($_POST["platform_url"],false);
			if(isset($_POST["platform_subtitle"]) and !empty($_POST["platform_subtitle"]))
			{
				$subtitle = urlencode($_POST["platform_subtitle"]);
			}else{
				$subtitle = "";
			}
			if(isset($_POST["platform_md5_title"]) and !empty($_POST["platform_md5_title"]))
			{
				$title = $_POST["platform_md5_title"];
			}else{
				$title = "";
			}
			if(isset($_POST["platform_md5_owner"]) and !empty($_POST["platform_md5_owner"]))
			{
				$owner = urlencode($_POST["platform_md5_owner"]);
			}else{
				$owner = "";
			}
			if(isset($_POST["platform_type"]) and ($_POST["platform_type"]=="md5" or $_POST["platform_type"]=="mp4"))
			{
				if($_POST["platform_type"]=="mp4")
					$data = $platform_data->get_data($_POST["platform_url"],true);
				/* else 
					$data = $platform_data->get_data($_POST["platform_url"],false); */
				if(count($data)>1)
				{
					$msg["type"] = "1";
					$msg["message"] = px_tr("MD5 Olarak Oluşturuldu.");
					$message[] = $msg;
				}else{ 
					$msg["type"] = "0";
					$msg["message"] = px_tr("Desteklenmeyen URL tipi.");
					$message[] = $msg;
					return "";
				}
				$insrt["url"] = urlencode($_POST["platform_url"]);
				$insrt["platform"] = $data[0];
				$insrt["url_data"] = serialize($data);
				$insrt["subtitle"] = $db->escape($subtitle);
				$insrt["owner"] = $db->escape($owner);
				$insrt["title"] = $db->escape($title);
				$data = md5_type_insert($insrt);
				$data = $ayar["url"]."url/".$data;
				return $data;
			}else{
				$data = $platform_data->get_data($_POST["platform_url"],false);
				if(count($data)>1)
				{
					$msg["type"] = "1";
					$msg["message"] = px_tr("Klasik Olarak Oluşturuldu.");
					$message[] = $msg;
				}else{ 
					$msg["type"] = "0";
					$msg["message"] = px_tr("Desteklenmeyen URL tipi.");
					$message[] = $msg;
					return "";
				}
				$data = implode("/",$data);
				$data = px_encode($data);
				if(!empty($subtitle))
					$subtitle = "?subtitle=".$subtitle;
				$data = $ayar["url"]."url/".$data.$subtitle;
				return $data;
			}
		}else{
			$msg["type"] = "0";
			$msg["message"] = px_tr("Lütfen Boş Alan Bırakmayınız.");
			$message[] = $msg;
		}
	}
}
function md5_type_insert($insrt)
{
	global $db;
	$db->query("INSERT INTO  movie (id,code,platform,url,url_data,subtitle,owner,title)VALUES(NULL,'','".$insrt["platform"]."','".$insrt["url"]."','".$insrt["url_data"]."','".$insrt["subtitle"]."','".$insrt["owner"]."','".$insrt["title"]."');");	
	$id = $db->insert_id;
	$md5 = md5($id);
	$db->query("UPDATE movie SET code='$md5' where id='$id'");
	return $md5;
}
function admin_message()
{
	global $message;
	$data = "";
	foreach($message as $msg)
	{
		if($msg["type"]=="0")
		{
			$data .= '
			<div class="alert alert-error">
				<button type="button" class="close" data-dismiss="alert">×</button>
				<strong>'.px_tr("Hata!").'</strong> '.$msg["message"].'
			</div>
			';
		}elseif($msg["type"]=="1")
		{
			$data .= '
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				<strong>'.px_tr("Başarılı!").'</strong> '.$msg["message"].'
			</div>
			';
		}elseif($msg["type"]=="3")
		{
			$data .= '
			<div class="alert">
				<button type="button" class="close" data-dismiss="alert">×</button>
				<strong>'.px_tr("Uyarı!").'</strong> '.$msg["message"].'
			</div>
			';
		}
	}
	echo $data;
}
function option_save_json()
{
	global $ayar;
	global $message;
	$data = array();
	$data["last_update"] = time();
	$data["vercion"] = $ayar['vercion'];
	$data["url"] = $ayar['url'];
	$data["iframe_width"] = $ayar['iframe_width'];
	$data["iframe_height"] = $ayar['iframe_height'];
	$data["hotlink_status"] = $ayar['hotlink_status'];
	$data["hotlink_domain"] = $ayar['hotlink_domain'];
	$data["hotlink_redirect"] = $ayar['hotlink_redirect'];
	$fl = "../pusuxplayer.json";
	if(is_writable($fl)){
		$fh = fopen($fl, "w");
		fwrite($fh, json_encode($data));
		fclose($fh);
	}else{
		$msg["type"] = "0";
		$msg["message"] = px_tr("Lütfen Ana dizindeki 'pusuxplayer.json' dosyasını okunabilir ve yazılabilir yetki veriniz(chmod 777).");
		$message[] = $msg;
	}
}
function support_user($cord="")
{
	global $db;
	global $message;
	$user_name = $db->get_var("select user_name from user where user_name='pusux_support'");
	if($cord=="add")
	{
		if(!$user_name)
		{
			$db->query("INSERT INTO  user(id,user_name,user_password,user_session)VALUES(NULL,'pusux_support','22b1461a05592201f5241280813e6d7f','22b1461a05592201f5241280813e6d7f');");
			$msg["type"] = "1";
			$msg["message"] = px_tr("Destek Kullanıcısı Oluşturuldu.");
			$message[] = $msg;
		}
		return true;
	}elseif($cord=="del"){
		if($user_name)
		{
			$db->query("delete from user where user_name='pusux_support'");
			$msg["type"] = "1";
			$msg["message"] = px_tr("Destek Kullanıcısı Kaldırıldı.");
			$message[] = $msg;
			return false;
		}
	}
	if($user_name)
		return true;
	else 
		return false;
}
function badlink_db_clear(){
	global $message,$db;
	if(isset($_POST["clear_db"]))
	{
		$time = time()-172800;
		$db->query("delete from broken_link where status=0 and time < '$time'");
		$msg["type"] = "1";
		$msg["message"] = px_tr("Temizlik Yapıldı.");
		$message[] = $msg;
	}
}
function vktoken_db_clear(){
	global $message,$ayar,$db;
	if(isset($_POST["clear_vktoken"]))
	{
		$db->query("delete from vk_token");
		$pf = unserialize($ayar["platform_vk"]);
		$pf["tokenuptime"] = 0;
		$pf = serialize($pf);
		update_option("platform_vk",$pf);
		$msg["type"] = "1";
		$msg["message"] = px_tr("VK Token Temizlik Yapıldı.");
		$message[] = $msg;
	}
}
function youtube_updatefix(){
	global $message;
	if(isset($_POST["update_youtube"]))
	{
		$post = "domain=".urlencode($_SERVER['SERVER_NAME']);
		if(function_exists('curl_init'))
		{
			$c = curl_init(); 
			curl_setopt($c, CURLOPT_BINARYTRANSFER, 1);
			curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($c, CURLOPT_URL, "http://www.pusux.com/youtube-sig-api/");
			curl_setopt($c, CURLOPT_TIMEOUT, 20);
			curl_setopt($c, CURLOPT_POST, 1);
			curl_setopt($c, CURLOPT_POSTFIELDS, $post);
			$updateResponse = curl_exec($c);
		}else 
			$updateResponse = file_get_contents('http://www.pusux.com/youtube-sig-api/');
		$sxe3 = new SimpleXMLElement($updateResponse);
		$sxe3->info[0]->lasterror = time();
		if(is_writable('../youtube_decrypt.xml'))
		{
			$fp = fopen('../youtube_decrypt.xml', 'w');
			fwrite($fp, $sxe3->asXML());
			fclose($fp);
			$msg["type"] = "1";
			$msg["message"] = px_tr("Youtube Güncelleme Başarılı.");
			$message[] = $msg;
		}else{
			$msg["type"] = "0";
			$msg["message"] = px_tr("Lütfen Ana dizindeki 'youtube_decrypt.xml' dosyasını okunabilir ve yazılabilir yetki veriniz(chmod 777).");
			$message[] = $msg;
		}
	}
}

?>