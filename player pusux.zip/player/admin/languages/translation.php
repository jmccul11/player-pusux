<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
class translation_pusux{
	//private $lang = "";
	private $filename = "";
	public $translation_list = array();
	function __construct($filename){
		//$this->lang = $lang;
		if($filename=="tr" or $filename=="")
		{
			$this->filename = "";
			return false;
		}
		$filename = "./languages/".$filename.".lang";
		$this->filename = $filename;
		$this->translation_list();
	}
	
	function translation_list()
	{
		$data = $this->tr_fileread();
		$list = $this->translation_list;
		preg_match_all('@\#:(.*?)\#;@si',$data,$salt_tr);
		foreach($salt_tr[1] as $value){
			preg_match('@id "(.*?)".*?tr "(.*?)"@si',$value,$id);
			$list[$id[1]] = $id[2];
		}
		$this->translation_list = $list;
	}
	
	function tr_fileread(){
		$fl = $this->filename;
		if(is_readable($fl)){
			$fh = fopen($fl, "r");
			$data = fread($fh,filesize($fl));
			fclose($fh);
			
		}else{
			$data = false;
		}
		return $data;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

?>