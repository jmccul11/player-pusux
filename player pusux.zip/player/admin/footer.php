<?php /*b78060ea9121f5151d27d9cf8fdc7b0f*/ ?>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
        <div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2016 Pusux.com </b>All rights reserved.
            </div>
        </div>
        <script src="<?=get_home_url()?>admin/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="<?=get_home_url()?>admin/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="<?=get_home_url()?>admin/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?=get_home_url()?>admin/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="<?=get_home_url()?>admin/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="<?=get_home_url()?>admin/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="<?=get_home_url()?>admin/scripts/common.js" type="text/javascript"></script>
    </body>
</html>