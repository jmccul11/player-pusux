<?php 
if(isset($_GET["script_update"]) and $_GET["script_update"]=="1"):
	if($ayar["vercion"]=="3.0"):
		$create_table_vk_tken = "CREATE TABLE IF NOT EXISTS `vk_token` (
		  `id` int(3) NOT NULL AUTO_INCREMENT,
		  `user` varchar(100) CHARACTER SET utf8 COLLATE utf8_turkish_ci NOT NULL,
		  `token` text CHARACTER SET utf8 COLLATE utf8_turkish_ci,
		  `date` bigint(20) NOT NULL,
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
		$db->hide_errors();
		$db->query($create_table_vk_tken);
		$db->query("INSERT INTO ayarlar (id,bolum,deger)VALUES(NULL,'jw_button','a:2:{s:4:\"mode\";s:1:\"1\";s:8:\"download\";s:1:\"1\";}')");
		update_option("platform_vk",'a:5:{s:6:"status";s:1:"5";s:4:"mode";s:5:"html5";s:11:"tokenuptime";i:0;s:10:"PX_VK_MAIL";s:13:"user@mail.com";s:10:"PX_VK_PASS";s:4:"pass";}');
		update_option("vercion","3.1");
	endif;
endif;
?>