<?php 
if(isset($_GET["script_update"]) and $_GET["script_update"]=="1"):
	if($ayar["vercion"]=="3.1"):
		$db->hide_errors();
		$db->query("INSERT INTO ayarlar (id,bolum,deger)VALUES(NULL,'platform_facebook','a:2:{s:6:\"status\";s:1:\"3\";s:4:\"mode\";s:5:\"flash\";}')");
		$db->query("INSERT INTO ayarlar (id,bolum,deger)VALUES(NULL,'platform_photos','a:2:{s:6:\"status\";s:1:\"3\";s:4:\"mode\";s:5:\"flash\";}')");
		update_option("vercion","3.2");
	endif;
endif;
?>