<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
admin_option_save();
?>
<div class="span9">
	<div class="content">
		<!--/#btn-controls-->
		<?php admin_message(); ?>
		<div class="module">
			<div class="module-head">
				<h3><?=px_tr("Ayarlar")?></h3>
			</div>
			<div class="module-body">
					<form method="post" action="" class="form-horizontal row-fluid">
						<div class="control-group">
							<label class="control-label" for="url"><?=px_tr("Player Adresi(URL)")?></label>
							<div class="controls">
								<input type="text" name="url" id="url" placeholder="http://" class="span8" value="<?=$ayar["url"]?>">
								<span class="help-inline"><?=px_tr("Playerin kurulu olduğu adres(URL)")?></span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="language"><?=px_tr("Yönetim Paneli Dili")?></label>
							<div class="controls">
								<select name="language" id="language" tabindex="1" class="span8">
									<option value="tr" <?php if($ayar["language"] =="tr") echo "selected" ?>>Türkçe(Default)</option>
									<option value="en" <?php if($ayar["language"] =="en") echo "selected" ?>>English</option>
								</select>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="htmlcode">Extra <?=px_tr("Html Kodu(JW player ve Alternatif)")?></label>
							<div class="controls">
								<textarea name="htmlcode" id="htmlcode" rows="5" class="span8"><?=stripcslashes($ayar["htmlcode"])?></textarea>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="hotlink_status"><?=px_tr("Koruma Modulü(Hotlink)")?></label>
							<div class="controls">
								<select name="hotlink_status" id="hotlink_status" tabindex="1" class="span8">
									<option value="1" <?php if($ayar["hotlink_status"] =="1") echo "selected" ?>><?=px_tr("Açık")?></option>
									<option value="0" <?php if($ayar["hotlink_status"] =="0") echo "selected" ?>><?=px_tr("Kapalı")?></option>
								</select>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="hotlink_domain"><?=px_tr("Koruma Modulü Domain")?></label>
							<div class="controls">
								<input type="text" name="hotlink_domain" id="hotlink_domain" placeholder="pusux.com" class="span8" value="<?=$ayar["hotlink_domain"]?>">
								<span class="help-inline">(<?=px_tr("http ve www. olmadan")?>)</span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="hotlink_redirect"><?=px_tr("Koruma Modulü Yönlendirme Adresi")?></label>
							<div class="controls">
								<input type="text" name="hotlink_redirect" id="hotlink_redirect" placeholder="http://pusux.com" class="span8" value="<?=$ayar["hotlink_redirect"]?>">
								<span class="help-inline"></span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="iframe_width"><?=px_tr("iFrame Genişlik")?></label>
							<div class="controls">
								<div class="input-append">
									<input type="text" name="iframe_width" id="iframe_width" placeholder="600" class="span8" value="<?=$ayar["iframe_width"]?>"><span class="add-on">px</span>
								</div>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="iframe_height"><?=px_tr("iFrame Yükseklik")?></label>
							<div class="controls">
								<div class="input-append">
									<input type="text" name="iframe_height" id="iframe_height" placeholder="400" class="span8" value="<?=$ayar["iframe_height"]?>"><span class="add-on">px</span>
								</div>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_licence"><?=px_tr("JW Player Lisans")?></label>
							<div class="controls">
								<input type="text" name="jw_licence" id="jw_licence" placeholder="" class="span8" value="<?=$ayar["jw_licence"]?>">
								<span class="help-inline"></span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_theme"><?=px_tr("JW Player Tema")?></label>
							<div class="controls">
								<input type="text" name="jw_theme" id="jw_theme" placeholder="Tema adı veya xml link" class="span8" value="<?=$ayar["jw_theme"]?>">
								<span class="help-inline"></span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_background"><?=px_tr("JW Player Arkaplan")?></label>
							<div class="controls">
								<input type="text" name="jw_background" id="jw_background" placeholder="http://" class="span8" value="<?=$ayar["jw_background"]?>">
								<span class="help-inline"></span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_logo"><?=px_tr("JW Player Logo")?></label>
							<div class="controls">
								<input type="text" name="jw_logo" id="jw_logo" placeholder="http://" class="span8" value="<?=$ayar["jw_logo"]?>">
								<span class="help-inline"></span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_logourl"><?=px_tr("JW Player Logo Link")?></label>
							<div class="controls">
								<input type="text" name="jw_logourl" id="jw_logourl" placeholder="http://" class="span8" value="<?=$ayar["jw_logourl"]?>">
								<span class="help-inline"></span>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_autostart"><?=px_tr("JW Player Otomatik Başlatma")?></label>
							<div class="controls">
								<select name="jw_autostart" id="jw_autostart" tabindex="1" class="span8">
									<option value="1" <?php if($ayar["jw_autostart"] =="1") echo "selected" ?>><?=px_tr("Açık")?></option>
									<option value="0" <?php if($ayar["jw_autostart"] =="0") echo "selected" ?>><?=px_tr("Kapalı")?></option>
								</select>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_session"><?=px_tr("JW Player Kaldığı Yerden Devam Etme")?></label>
							<div class="controls">
								<select name="jw_session" id="jw_session" tabindex="1" class="span8">
									<option value="1" <?php if($ayar["jw_session"] =="1") echo "selected" ?>><?=px_tr("Açık")?></option>
									<option value="0" <?php if($ayar["jw_session"] =="0") echo "selected" ?>><?=px_tr("Kapalı")?></option>
								</select>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_mobile_mode"><?=px_tr("JW Player Mobil Modu")?></label>
							<div class="controls">
								<select name="jw_mobile_mode" id="jw_mobile_mode" tabindex="1" class="span8">
									<option value="html5" <?php if($ayar["jw_mobile_mode"] =="html5") echo "selected" ?>>HTML5</option>
									<option value="flash" <?php if($ayar["jw_mobile_mode"] =="flash") echo "selected" ?>>Flash</option>
								</select>
							</div>
						</div>
						
						<!--button setting-->
						<?php $button = unserialize($ayar["jw_button"]); ?>
						<div class="control-group">
							<label class="control-label" for="jw_button_mode"><?=px_tr("JW Player Mod Butonu")?></label>
							<div class="controls">
								<select name="jw_button[mode]" id="jw_button_mode" tabindex="1" class="span8">
									<option value="1" <?php if($button["mode"] =="1") echo "selected" ?>><?=px_tr("Açık")?></option>
									<option value="0" <?php if($button["mode"] =="0") echo "selected" ?>><?=px_tr("Kapalı")?></option>
								</select>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="jw_button_download"><?=px_tr("JW Player İndirme Butonu")?></label>
							<div class="controls">
								<select name="jw_button[download]" id="jw_button_download" tabindex="1" class="span8">
									<option value="1" <?php if($button["download"] =="1") echo "selected" ?>><?=px_tr("Açık")?></option>
									<option value="0" <?php if($button["download"] =="0") echo "selected" ?>><?=px_tr("Kapalı")?></option>
								</select>
							</div>
						</div>
						<!--button setting-->
						
						<?php foreach($platform_list as $platformn=>$value)://platform_list in function.php ?>
						<!--platform start-->
						<?php 
						$platform = platform_form_data($ayar[$platformn]);
						?>
						<div id="<?=$platformn?>" class="media stream new-update">
							<a href="#<?=$platformn?>">
								<i class="icon-sort-down shaded"></i>
								<?=$value["text"]?>
							</a>
						</div>
						<div class="control-group">
							<label class="control-label"><?=px_tr("Çözüm Tipi")?></label>
							<div class="controls">
								<select name="<?=$platformn?>[status]" tabindex="1" class="span8">
									<?php if(in_array("jwplayer", $value["type"])): ?><option value="jwplayer" <?php if($platform["status"] =="jwplayer") echo "selected" ?>>Jw Player</option><?php endif; ?>
									<?php if(in_array("alternative", $value["type"])): ?><option value="alternative" <?php if($platform["status"] =="alternative") echo "selected" ?>><?=px_tr("Alternatif Çözüm")?></option><?php endif; ?>
									<?php if(in_array("redirect", $value["type"])): ?><option value="redirect" <?php if($platform["status"] =="redirect") echo "selected" ?>><?=px_tr("Yönlendirici(301)")?></option><?php endif; ?>
								</select>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label"><?=px_tr("Kırık Link Modu")?></label>
							<div class="controls">
								<select name="<?=$platformn?>[bad]" tabindex="1" class="span8">
									<option value="1" <?php if($platform["bad"] =="1") echo "selected" ?>><?=px_tr("Açık")?></option>
									<option value="0" <?php if($platform["bad"] =="0") echo "selected" ?>><?=px_tr("Kapalı")?></option>
								</select>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label"><?=px_tr("JW Player Modu")?></label>
							<div class="controls">
								<select name="<?=$platformn?>[mode]" tabindex="1" class="span8">
									<option value="html5" <?php if($platform["mode"] =="html5") echo "selected" ?>>HTML5</option>
									<option value="flash" <?php if($platform["mode"] =="flash") echo "selected" ?>>Flash</option>
								</select>
							</div>
						</div>
						<!--platform finish-->
						<!--vk private seting-->
						<?php if($platformn=="platform_vk"): ?>
						<?php $priv_vk = unserialize($ayar["platform_vk"]);?>
						<div class="control-group">
							<label class="control-label"><?=px_tr("VK Mail")?></label>
							<div class="controls">
								<input type="text" name="PX_VK_MAIL" id="basicinput" placeholder="vkuser@mail" class="span8" value="<?=$priv_vk["PX_VK_MAIL"]?>">
								<span class="help-inline"></span>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label"><?=px_tr("VK Password")?></label>
							<div class="controls">
								<input type="text" name="PX_VK_PASS" id="basicinput" placeholder="vkuser pass" class="span8" value="<?=$priv_vk["PX_VK_PASS"]?>">
								<span class="help-inline"></span>
							</div>
						</div>
						<?php endif;?>
						<!--vk private seting-->
						<?php endforeach; ?>
						
						<div class="control-group">
							<div class="controls">
								<button type="submit" class="btn btn-large btn-inverse" name="option_save" value="option_save"><?=px_tr("Güncelle")?></button>
							</div>
						</div>
					</form>
			</div>
		</div>
		<!--/.module-->
	</div>
	<!--/.content-->
</div>
<!--/.span9-->