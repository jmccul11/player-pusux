<?php
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
if(isset($_GET['s']) and !empty($_GET['s']))
{
	$search = $db->escape(urldecode($_GET['s']));
	$getp = "&s=".$search;
	$search = "WHERE title LIKE '%".$search."%'";
}else{
	$search = "";
	$getp = "";
}
$listcount = 25; 
$count = $db->get_var("select count(id) from movie ".$search);
$p = isset($_GET['p']) ? (int) $_GET['p'] : 1;
if($p < 1) $p = 1; 
if($p > $count) $p = $count; 
$limit = ($p - 1) * $listcount;
if($limit<1) $limit = 0;
?>
<div class="span9">
	<div class="content">
		<div class="module">
			<div class="module-head">
				<h3><?=px_tr("Bağlantılar")?></h3>
			</div>
			<div class="module-body table">
				<div class="dataTables_wrapper">
					<div class="dataTables_length">
						<label><?=px_tr("Sayfa")?>: 
							<select id="pageselect" size="1"  onchange="window.location = jQuery('#pageselect option:selected').val();">
								<option value=""><?=px_tr("Seç")?></option>
								<?php 
									$pagecount = ceil($count / $listcount);
									for($s = 1; $s <= $pagecount; $s++):
								?>
								<option value="<?=get_home_url()?>admin/linkler.html?p=<?=$s.$getp?>"><?=$s?></option>
								<?php endfor; ?>
							</select>
						</label>
					</div>
					<div class="dataTables_filter">
						<form action="<?=get_home_url()?>admin/linkler.html" method="get">
							<label><?=px_tr("Ara")?>: <input name="s" type="text" placeholder="<?=px_tr("Başlık içerisinde ara")?>">
							<button class="btn btn-standart btn-success"><?=px_tr("Ara")?></button>
							</label>
						</form>
					</div>
				</div>
				
				
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped" width="100%">
					<thead>
						<tr>
							<th><?=px_tr("Başlık")?>/<?=px_tr("Sahip URL")?></th>
							<th>Platform</th>
							<th><?=px_tr("Altyazı URL")?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
					<?php 
					
					$rows = $db->get_results('select * from movie ' . $search . ' order by id DESC LIMIT ' . $limit . ', ' . $listcount);
					if($rows):
					foreach ( $rows as $row ):
					?>
						<tr class="odd gradeX">
							<td>
								<a data-toggle="tooltip" title="<?=urldecode($row->owner)?>" href="<?=urldecode($row->owner)?>" target="_blank"><?=$row->title?></a>
							</td>
							<td>
								<a data-toggle="tooltip" title="<?=urldecode($row->url)?>" href="<?=urldecode($row->url)?>" target="_blank"><code><?=ucwords($row->platform)?></code></a>
							</td>
							<td>
								<?php echo($row->subtitle=="") ? "-" : '<a data-toggle="tooltip" title="'.urldecode($row->subtitle).'" href="'.urldecode($row->subtitle).'" target="_blank">'.px_tr("Önizle").'</a>'; ?>
							</td>
							<td class="center">
								<a href="<?=get_home_url()?>url/<?=$row->code?>" class="btn btn-info pull-right" style="margin-left:0 10px;" target="_blank"><?=px_tr("Önizle")?></a> 
								<a href="<?=get_home_url()?>admin/link-duzenle.html?link_id=<?=$row->id?>" class="btn btn-info pull-right" style="margin:0 10px;"><?=px_tr("Güncelle")?></a>
								<a href="<?=get_home_url()?>admin/link-duzenle.html?del_link_id=<?=$row->id?>" class="btn btn-danger pull-right" onclick="return confirm('Sileceğinize Eminmisiniz?')"><?=px_tr("Sil")?></a>
							</td>
						</tr>
						
					<?php endforeach;endif; ?>	
					</tbody>
					
				</table>
			</div>
		</div>
		<!--/.module-->
	</div>
	<!--/.content-->
</div>
<!--/.span9-->