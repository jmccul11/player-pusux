<?php /*b78060ea9121f5151d27d9cf8fdc7b0f*/ ?>
<?php
include("./update-3.2.php");
?> 
<div class="span9">
	<div class="content">
		<div class="btn-controls">
			<div class="btn-box-row row-fluid">
				<a href="#" class="btn-box big span4"><i class="icon-exchange"></i><b><?=$ayar["vercion"]?></b>
					<p class="text-muted">
						<?=px_tr("Versiyon")?></p>
				</a><a href="<?=get_home_url()?>admin/linkler.html" class="btn-box big span4"><i class="icon-film"></i><b><?=$db->get_var("select count(id) from movie");?></b>
					<p class="text-muted">
						<?=px_tr("Bağlantılar")?></p>
				</a><a href="<?=get_home_url()?>admin/kirik-linkler.html" class="btn-box big span4"><i class="icon-trash"></i><b><?=$db->get_var("select count(id) from broken_link where status=1");?></b>
					<p class="text-muted">
						<?=px_tr("Kırık Bağlantılar")?></p>
				</a>
			</div>
		</div>
		<!--/#btn-controls-->
		<?php if($ayar["vercion"]=="3.1"): ?>
		<div class="module show" style="background-color:#FFD5D5;">
			<div class="module-head">
				<h3><?=px_tr("Güncelleme")?></h3>
			</div>
			<div class="module-body">
				<form action="" method="get">				
					<div class="form-inline clearfix">
						<label for="amount">
							Buradan Yapılacak Güncelleme İşlemi Yalnızca veritabanında işlem yapacaktır.Pusux.com üzerinden güncelleme dosyalarını FTP üzerinden gönderip yazdırdığınıza emin olunuz.İşlemi Başlatmak için:
							<br><br>
						</label>
						<input type="hidden" name="script_update" value="1">
						<button class="btn btn-large btn-danger"><?=px_tr("Güncelle")?></button>
					</div>
				</form>
				<hr />
				<div class="slider-range">
				</div>
			</div>
		</div>
		<?php endif; ?>
		<div class="module show">
			<div class="module-head">
				<h3><?=px_tr("Bağlantılar içerisinde ara")?></h3>
			</div>
			<div class="module-body">
				<form action="<?=get_home_url()?>admin/linkler.html" method="get">				
					<div class="form-inline clearfix">
						<button class="btn btn-standart btn-success pull-right"><?=px_tr("Ara")?></button>
						<label for="amount"><?=px_tr("Ara")?>:</label>
						&nbsp;
						<input name="s" type="text" placeholder="<?=px_tr("Başlık içerisinde ara")?>">
					</div>
				</form>
				<hr />
				<div class="slider-range">
				</div>
			</div>
		</div>
		
		<div class="module">
			<div class="module-head">
				<h3><?=px_tr("Haber Akışı")?></h3>
			</div>
			<div class="module-body">
				<iframe src="http://www.pusux.com/pusuxplayer/feed/" style="width:100%;height:500px;border:0;"></iframe>
				<div class="stream-list">
					<!--<div class="media stream">
						<div class="media-body">
							<div class="stream-headline">
								<h5 class="stream-author">
									John Donga 
									<small>08 July, 2014</small>
								</h5>
								<div class="stream-text">
									 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type. 
								
								</div>
							</div>
						</div>
					</div>--><!--/.media .stream-->
					<div class="media stream load-more">
						<a href="http://www.pusux.com/pusuxplayer/feed/">
							<i class="icon-refresh shaded"></i>
							<?=px_tr("Daha fazla göster")?>...
						</a>
					</div>
				</div><!--/.stream-list-->
			</div><!--/.module-body-->
		</div>
	</div>
	<!--/.content-->
</div>
<!--/.span9-->