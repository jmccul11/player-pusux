<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
if(get_login_status())
{
	header("Refresh: 0; url=./index.html");
	exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?=px_tr("Pusux Player Yönetim Paneli")?></title>
	<link type="text/css" href="<?=get_home_url()?>/admin/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="<?=get_home_url()?>/admin/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="<?=get_home_url()?>/admin/css/theme.css" rel="stylesheet">
	<link type="text/css" href="<?=get_home_url()?>/admin/images/icons/css/font-awesome.css" rel="stylesheet">
	<!--<link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>-->
	
</head>
<body>
	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
					<i class="icon-reorder shaded"></i>
				</a>
			  	<a class="brand" href="index.html">
			  		<?=px_tr("Pusux Player Yönetim Paneli")?>
			  	</a>
			</div>
		</div><!-- /navbar-inner -->
	</div><!-- /navbar -->
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="module module-login span4 offset4">
					<form action="" method="post" class="form-vertical">
						<div class="module-head">
							<h3><?=px_tr("Giriş Yap")?></h3>
						</div>
						<div class="module-body">
							<div class="control-group">
								<div class="controls row-fluid">
									<input class="span12" type="text" name="user_name" id="inputEmail" placeholder="Username">
								</div>
							</div>
							<div class="control-group">
								<div class="controls row-fluid">
									<input class="span12" type="password" name="user_password" id="inputPassword" placeholder="Password">
								</div>
							</div>
							<div class="control-group">
								<?php admin_message(); ?>
							</div>
						</div>
						<div class="module-foot">
							<div class="control-group">
								<div class="controls clearfix">
									<button type="submit" class="btn btn-primary pull-right"><?=px_tr("Giriş Yap")?></button>
									<label class="checkbox">
										
									</label>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div><!--/.wrapper-->
	<div class="footer">
		<div class="container">
			<b class="copyright">&copy; 2016 Pusux.com </b> All rights reserved.
		</div>
	</div>
	<script src="<?=get_home_url()?>/admin/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="<?=get_home_url()?>/admin/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="<?=get_home_url()?>admin/scripts/flot/jquery.flot.cute.js.php" type="text/javascript"></script>
	<script src="<?=get_home_url()?>/admin/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</body>