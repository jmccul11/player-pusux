<?php /*b78060ea9121f5151d27d9cf8fdc7b0f*/ ?>
<?php $data = platform_url_create(); ?>
<div class="span9">
	<div class="content">
		<!--/#btn-controls-->
		<?php admin_message(); ?>
		<div class="module">
			<div class="module-head">
				<h3><?=px_tr("Bağlantı Oluştur")?></h3>
			</div>
			<div class="module-body">
				<form method="post" action="" class="form-horizontal row-fluid">
					<div class="control-group">
						<label class="control-label" for="basicinput">Platform URL</label>
						<div class="controls">
							<input type="text" name="platform_url" id="basicinput" placeholder="http://" class="span8" value="">
							<span class="help-inline">Platform URL</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Altyazı URL")?></label>
						<div class="controls">
							<input type="text" name="platform_subtitle" id="basicinput" placeholder="http://" class="span8" value="">
							<span class="help-inline"><?=px_tr("Uzantı")?>:srt</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Platform Tipi")?></label>
						<div class="controls">
							<select id="platform_type" name="platform_type" tabindex="1" class="span8" onchange="sbxx()">
								<option value="classic"><?=px_tr("Klasik")?></option>
								<option value="md5">MD5</option>
								<option value="mp4">Mp4 Stream</option>
							</select>
							<span class="help-inline"><?=px_tr("Oluşturma ve Şifreleme Tipi")?></span>
						</div>
					</div>
					<div class="control-group">
					</div>
					<div id="md5data" style="display:none;">
						<div class="control-group">
							<label class="control-label" for="basicinput"><?=px_tr("Başlık")?></label>
							<div class="controls">
								<input type="text" name="platform_md5_title" id="basicinput" placeholder="<?=px_tr("Film Adı")?>/part" class="span8" value="">
								<span class="help-inline"></span>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="basicinput"><?=px_tr("Sahip URL")?></label>
							<div class="controls">
								<input type="text" name="platform_md5_owner" id="basicinput" placeholder="http://" class="span8" value="">
								<span class="help-inline"><?=px_tr("Kullanacağınız yer")?></span>
							</div>
						</div>
						<br>
					</div>
					<script>
					function sbxx(){
						var platformtype = $( "#platform_type option:selected" ).val();
						if(platformtype=="md5")
						{
							$( "#md5data" ).show();
						}else if(platformtype=="mp4")
						{
							$( "#md5data" ).show();
						}else{
							$( "#md5data" ).hide();
						}
					}
					</script>
					<div class="control-group">
						<div class="controls">
							<button type="submit" class="btn btn-large btn-inverse" name="generate_url" value="generate_url"><?=px_tr("Oluştur")?></button>
						</div>
					</div>
				</form>
				<?php 
				
				if(!empty($data)):
				?>
				<br><br>
				<ul class="nav nav-tabs">
					<li class="active"><a data-toggle="tab" href="#home">URL</a></li>
					<li><a data-toggle="tab" href="#menu1"><?=px_tr("iFrame Kodu")?></a></li>
					<li><a data-toggle="tab" href="#menu2"><?=px_tr("Önizle")?></a></li>
				</ul>
				
				<div class="tab-content">
					<div id="home" class="tab-pane fade in active">
						<div class="docs-example">
							<textarea style="width:100%;"><?=$data?></textarea>
						</div>
					</div>
					<div id="menu1" class="tab-pane fade">
						<div class="docs-example">
							<textarea style="width:100%;"><iframe width="<?=$ayar["iframe_width"]?>" height="<?=$ayar["iframe_height"]?>" src="<?=$data?>" frameborder="0" allowfullscreen></iframe></textarea>
						</div>
					</div>
					<div id="menu2" class="tab-pane fade">
						<div class="docs-example">
							<iframe width="100%" height="<?=$ayar["iframe_height"]?>" src="<?=$data?>" frameborder="0" allowfullscreen></iframe>
						</div>
					</div>
				</div>
				<?php 
				endif;
				?>
			</div>
		</div>
		<!--/.module-->
	</div>
	<!--/.content-->
</div>
<!--/.span9-->