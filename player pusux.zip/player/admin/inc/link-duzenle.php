<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
if(isset($_GET["del_link_id"]) and is_numeric($_GET["del_link_id"]))
{
	$msg["type"] = "1";
	$msg["message"] = "Veritabanından Başarıyla Silindi!";
	$message[] = $msg;
	$link_id = (int)$_GET["del_link_id"];
	$db->query("delete from movie where id=".$link_id);
}
elseif(isset($_GET["link_id"]))
{
	$link_id = (int)$_GET["link_id"];
	//////////////////////////
	if(isset($_POST["update_url"])){
		$platform_data = new platform_generate_data();
		if($_POST["platform_type"]=="mp4")
			$data = $platform_data->get_data($_POST["platform_url"],true);
		else
			$data = $platform_data->get_data($_POST["platform_url"],false);
		
		if(isset($_POST["platform_subtitle"]) and !empty($_POST["platform_subtitle"]))
		{
			$subtitle = urlencode($_POST["platform_subtitle"]);
		}else{
			$subtitle = "";
		}
		if(isset($_POST["platform_md5_title"]) and !empty($_POST["platform_md5_title"]))
		{
			$title = $_POST["platform_md5_title"];
		}else{
			$title = "";
		}
		if(isset($_POST["platform_md5_owner"]) and !empty($_POST["platform_md5_owner"]))
		{
			$owner = urlencode($_POST["platform_md5_owner"]);
		}else{
			$owner = "";
		}
		if(count($data)>1)
		{
			$msg["type"] = "1";
			$msg["message"] = "Güncelleme Başarılı.";
			$message[] = $msg;
		}else{ 
			$msg["type"] = "0";
			$msg["message"] = "Desteklenmeyen URL tipi.";
			$message[] = $msg;
			return "";
		}
		$insrt["url"] = urlencode($_POST["platform_url"]);
		$insrt["platform"] = $data[0];
		$insrt["url_data"] = serialize($data);
		$insrt["subtitle"] = $db->escape($subtitle);
		$insrt["owner"] = $db->escape($owner);
		$insrt["title"] = $db->escape($title);
		$db->query("UPDATE movie SET url='".$insrt["url"]."',platform='".$insrt["platform"]."',url_data='".$insrt["url_data"]."',subtitle='".$insrt["subtitle"]."',owner='".$insrt["owner"]."',title='".$insrt["title"]."' where id='$link_id'");
		
	}
	///////////////////////////
	$row = $db->get_row("select * from movie where id='$link_id'");
	if($row)
	{
		$data = $ayar["url"]."url/".$row->code;
	}else{
		$msg["type"] = "0";
		$msg["message"] = "ID veritabanında bulunamadı!";
		$message[] = $msg;
	}
}else{
	$msg["type"] = "0";
	$msg["message"] = "ID bulunamadı yada Geçersiz ID!";
	$message[] = $msg;
}


?>
<div class="span9">
	<div class="content">
		<!--/#btn-controls-->
		<?php admin_message(); ?>
		<div class="module">
			<div class="module-head">
				<h3>Düzenle</h3>
			</div>
			<div class="module-body">
				<?php 
				if(isset($row) and $row):
				?>
				<form method="post" action="" class="form-horizontal row-fluid">
					<div class="control-group">
						<label class="control-label" for="basicinput">Platform URL</label>
						<div class="controls">
							<input type="text" name="platform_url" id="basicinput" placeholder="http://" class="span8" value="<?=urldecode($row->url)?>">
							<span class="help-inline">Platform URL</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput">Altyazı URL</label>
						<div class="controls">
							<input type="text" name="platform_subtitle" id="basicinput" placeholder="http://" class="span8" value="<?=urldecode($row->subtitle)?>">
							<span class="help-inline">Uzantı:srt</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput">Platform Type</label>
						<div class="controls">
							<select id="platform_type" name="platform_type" tabindex="1" class="span8">
								<option value="md5" <?php echo ($row->platform!="mp4") ? "selected" : ""; ?>>MD5</option>
								<option value="mp4" <?php echo ($row->platform=="mp4") ? "selected" : ""; ?>>Mp4 Stream</option>
							</select>
							<span class="help-inline">Oluşturma ve Şifreleme Tipi</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput">Başlık</label>
						<div class="controls">
							<input type="text" name="platform_md5_title" id="basicinput" placeholder="Film Adı/part" class="span8" value="<?=$row->title?>">
							<span class="help-inline"></span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput">Sahip URL</label>
						<div class="controls">
							<input type="text" name="platform_md5_owner" id="basicinput" placeholder="http://" class="span8" value="<?=urldecode($row->owner)?>">
							<span class="help-inline">Kullanacağınız yer</span>
						</div>
					</div>
					<br>
					
					
					<div class="control-group">
						<div class="controls">
							<button type="submit" class="btn btn-large btn-inverse" name="update_url" value="update_url">Güncelle</button>
						</div>
					</div>
				</form>
				<br><br>
				<ul class="nav nav-tabs">
					<li class="active"><a data-toggle="tab" href="#home">URL</a></li>
					<li><a data-toggle="tab" href="#menu1">iFrame Kodu</a></li>
					<li><a data-toggle="tab" href="#menu2">Önizle</a></li>
				</ul>
				
				<div class="tab-content">
					<div id="home" class="tab-pane fade in active">
						<div class="docs-example">
							<textarea style="width:100%;"><?=$data?></textarea>
						</div>
					</div>
					<div id="menu1" class="tab-pane fade">
						<div class="docs-example">
							<textarea style="width:100%;"><iframe width="<?=$ayar["iframe_width"]?>" height="<?=$ayar["iframe_height"]?>" src="<?=$data?>" frameborder="0" allowfullscreen></iframe></textarea>
						</div>
					</div>
					<div id="menu2" class="tab-pane fade">
						<div class="docs-example">
							<iframe width="100%" height="<?=$ayar["iframe_height"]?>" src="<?=$data?>" frameborder="0" allowfullscreen></iframe>
						</div>
					</div>
				</div>
				<?php 
				endif;
				?>
			</div>
		</div>
		<!--/.module-->
	</div>
	<!--/.content-->
</div>
<!--/.span9-->