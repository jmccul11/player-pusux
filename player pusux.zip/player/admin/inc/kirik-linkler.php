<?php
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
if(isset($_POST['del_badlink_id']) and !empty($_POST['del_badlink_id'])){
	foreach($_POST['del_badlink_id'] as $link_id){
		$db->query("delete from broken_link where id=".$link_id);
	}
	$msg["type"] = "1";
	$msg["message"] = px_tr("Seçilenler Başarıyla Silindi!");
	$message[] = $msg;
}
if(isset($_GET["del_badlink_id"]) and is_numeric($_GET["del_badlink_id"]))
{
	$msg["type"] = "1";
	$msg["message"] = px_tr("Seçilenler Başarıyla Silindi!");
	$message[] = $msg;
	$link_id = (int)$_GET["del_badlink_id"];
	$db->query("delete from broken_link where id=".$link_id);
}
$listcount = 25; 
$count = $db->get_var("select count(id) from broken_link where status=1");
$p = isset($_GET['p']) ? (int) $_GET['p'] : 1;
if($p < 1) $p = 1; 
if($p > $count) $p = $count; 
$limit = ($p - 1) * $listcount;
if($limit<1) $limit = 0;
?>
<div class="span9">
	<div class="content">
		<div class="module">
			<div class="module-head">
				<h3><?=px_tr("Kırık Bağlantılar")?></h3>
			</div>
			<div class="module-body table">
				<div class="dataTables_wrapper">
					<div class="dataTables_length">
						<label><?=px_tr("Sayfa")?>: 
							<select id="pageselect" size="1"  onchange="window.location = jQuery('#pageselect option:selected').val();">
								<option value=""><?=px_tr("Seç")?></option>
								<?php 
									$pagecount = ceil($count / $listcount);
									for($s = 1; $s <= $pagecount; $s++):
								?>
								<option value="<?=get_home_url()?>admin/kirik-linkler.html?p=<?=$s?>"><?=$s?></option>
								<?php endfor; ?>
							</select>
						</label>
					</div>
					<div class="dataTables_filter">
						<label>
							<button onclick="tumunusec()" class="btn btn-success"><?=px_tr("Tümünü Seç")?></button>
							<button onclick="tumunubirak()" class="btn btn-success"><?=px_tr("Tümünü Bırak")?></button>
							
						</label>
					</div>
				</div>
				<form action="" method="post">
				<table cellpadding="0" cellspacing="0" border="0" class="table table-striped" width="100%">
					<thead>
						<tr>
							<th></th>
							<th><?=px_tr("Tip")?></th>
							<th>Platform</th>
							<th><?=px_tr("Tarih")?></th>
							<th><?=px_tr("Referans")?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$platform_data = new platform_generate_data();
					$rows = $db->get_results('select * from broken_link where status=1 order by id DESC LIMIT ' . $limit . ', ' . $listcount);
					if($rows):
					foreach ( $rows as $row ):
						if($row->type=="md5")
							$row2 = $db->get_row('select * from movie where id='.$row->reg_id);
						else{
							$row2 = new stdClass();
							$row2->code = $row->get_data;
							$row2->url = urldecode($row->classic);
							$data = array();
							$data["data"] = $row->get_data;
							$data = px_classic_data($data);
							$row2->platform = $data["platform"];
						}
					?>
						<tr class="odd gradeX">
							
							<td>
								<input type="checkbox" name="del_badlink_id[]" value="<?=$row->id?>">
							</td>
							<td>
								<?=$row->type?>
							</td>
							<td>
								<a data-toggle="tooltip" title="<?=urldecode($row2->url)?>" href="<?=urldecode($row2->url)?>" target="_blank"><code><?=ucwords($row2->platform)?></code></a>
							</td>
							<td>
								<?=date('Y-m-d H:i:s',$row->time)?>
							</td>
							<td>
								<?php echo($row->referer=="") ? "-" : '<a data-toggle="tooltip" title="'.urldecode($row->referer).'" href="'.urldecode($row->referer).'" target="_blank">'.px_tr("Önizle").'</a>'; ?>
							</td>
							<td class="center">
								<a href="<?=get_home_url()?>url/<?=$row2->code?>" class="btn btn-info pull-right" style="margin-left:0 10px;" target="_blank"><?=px_tr("Önizle")?></a> 
								<?php if($row->reg_id!=0): ?>
								<a href="<?=get_home_url()?>admin/link-duzenle.html?link_id=<?=$row->reg_id?>" class="btn btn-info pull-right" style="margin:0 10px;"><?=px_tr("Güncelle")?></a>
								<?php else: ?>
								<a href="#" class="btn pull-right" style="margin:0 10px;"><?=px_tr("Güncelle")?></a>
								<?php endif; ?>
								<a href="<?=get_home_url()?>admin/kirik-linkler.html?del_badlink_id=<?=$row->id?>" class="btn btn-danger pull-right"><?=px_tr("Sil")?></a>
							</td>
						</tr>
						<?php unset($row2); ?>
					<?php endforeach;endif; ?>	
					</tbody>
				</table>
				<div class="dataTables_wrapper">
					<div class="dataTables_filter">
						<label>
							<button  class="btn btn-danger btn-success"><?=px_tr("Seçilenleri Sil")?></button>
						</label>
					</div>
				</div>
				</form>
			</div>
		</div>
		<!--/.module-->
		<script type="text/javascript">
		function tumunusec()
		{
			$("input:checkbox").each(function(){
				this.checked = true;
			});
		}
		function tumunubirak()
		{
			$("input:checkbox").each(function(){
				this.checked = false;
			});
		}
		</script>
	</div>
	<!--/.content-->
</div>
<!--/.span9-->