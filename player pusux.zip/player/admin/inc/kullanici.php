<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
$user = $_SESSION["user"];
if(isset($_POST['update_user']))
{
	if(isset($_POST['support_user']))		
	{
		if($_POST['support_user']=="1")
		{
			support_user("add");
		}else{
			support_user("del");
		}
	}
	if(isset($_POST['pusux_user']) and !empty($_POST['pusux_user']))			
	{
		$k = $db->escape($_POST['pusux_user']);
		$db->query("UPDATE user SET user_name='$k' where user_name='$user'");
		$user = $k;
		$_SESSION["user"] = $user;
		$msg["type"] = "1";
		$msg["message"] = px_tr("Kullanıcı Adı Güncelleme Başarılı.");
		$message[] = $msg;
	}
	if(isset($_POST['pusux_pass']) and isset($_POST['pusux_pass2']))			
	{
		$pass = $db->escape($_POST['pusux_pass']);
		$pass2 = $db->escape($_POST['pusux_pass2']);
		if(!empty($_POST['pusux_pass'])){
			if($pass==$pass2)
			{
				$pass = md5(md5($pass));
				$db->query("UPDATE user SET user_password='$pass' where user_name='$user'");
				$msg["type"] = "1";
				$msg["message"] = px_tr("Şifre Güncelleme Başarılı.");
				$message[] = $msg;
				$user_session = md5(md5($user.$pass)); 
				$_SESSION["login"] = $user_session;
				$_SESSION["user"] = $user;
			}else{
				$msg["type"] = "0";
				$msg["message"] = px_tr("Şifreler Eşleşmiyor!");
				$message[] = $msg;
			}
		}
	}
}
?>
<div class="span9">
	<div class="content">
		<!--/#btn-controls-->
		<?php admin_message(); ?>
		<div class="module">
			<div class="module-head">
				<h3><?=px_tr("Kullanıcı Bilgileri")?></h3>
			</div>
			<div class="module-body">
				<form method="post" action="" class="form-horizontal row-fluid">
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Kullanıcı Adı")?></label>
						<div class="controls">
							<input type="text" name="pusux_user" id="basicinput"  class="span8" value="<?=$user?>">
							<span class="help-inline"></span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Şifre")?></label>
						<div class="controls">
							<input type="password" name="pusux_pass" id="basicinput" class="span8" value="">
							<span class="help-inline"></span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Şifre Tekrar")?></label>
						<div class="controls">
							<input type="password" name="pusux_pass2" id="basicinput" class="span8" value="">
							<span class="help-inline"></span>
						</div>
					</div>
					<div class="control-group">
							<label class="control-label" for="basicinput"><?=px_tr("Destek Kullanıcısı")?></label>
							<div class="controls">
								<select name="support_user" tabindex="1" class="span8">
									<option value="1" <?php echo (support_user("")==true) ? "selected" : ""; ?>><?=px_tr("Açık")?></option>
									<option value="0" <?php echo (support_user("")==false) ? "selected" : ""; ?>><?=px_tr("Kapalı")?></option>
								</select>
								<span class="help-inline"><?=px_tr("Bu kullanıcı adı ve şifresi ancak Pusux ekibi tarafından bilinir.")?></span>
							</div>
						</div>
					<div class="control-group">
						<div class="controls">
							<button type="submit" class="btn btn-large btn-inverse" name="update_user" value="update_user"><?=px_tr("Güncelle")?></button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!--/.module-->
	</div>
	<!--/.content-->
</div>
<!--/.span9-->