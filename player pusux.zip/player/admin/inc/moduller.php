<?php /*b78060ea9121f5151d27d9cf8fdc7b0f*/ ?>
<?php badlink_db_clear(); ?>
<?php vktoken_db_clear(); ?>
<?php youtube_updatefix(); ?>
<div class="span9">
	<div class="content">
		<!--/#btn-controls-->
		<?php admin_message(); ?>
		<div class="module">
			<div class="module-head">
				<h3><?=px_tr("Ek Modüller")?></h3>
			</div>
			<div class="module-body">
				<form method="post" action="" class="form-horizontal row-fluid">
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Javascript Kodu")?></label>
						<div class="controls">
							<textarea class="span8" rows="5"><script>!function(d,h,s,id){var js,fjs=d.getElementsByTagName(h)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="<?=$ayar["url"]?>pusuxplayer.js?t=<?=time()?>";fjs.appendChild(js,fjs);}}(document,"head","script","pusux-player");</script></textarea>
							<span class="help-inline">
							<?=px_tr("Bu kod önceki videolarınızı JS kullanarak otomatik olarak Pusux Player üzerinde açmanızı sağlar.")?><br>
							<?=px_tr("Bu kodu Pusux Player ayarlarında yaptığınız değişikliklerden sonra lütfen güncelleyiniz.")?><br>
							<?=px_tr("Bu kodu <code>&lt;head&gt;&lt;/head&gt;</code> etiketleri arasında kullanınız.")?>
							</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Wordpress Eklentisi")?></label>
						<div class="controls">
							<a class="btn btn-mini btn-info" href="http://pusux.com/"><?=px_tr("İndir")?></a>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Veritabanı Temizliği")?></label>
						<div class="controls">
							<button type="submit" class="btn btn-mini btn-info" name="clear_db" value="clear_db"><?=px_tr("Temizle")?></button>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("VK Token Temizliği")?></label>
						<div class="controls">
							<button type="submit" class="btn btn-mini btn-info" name="clear_vktoken" value="clear_vktoken"><?=px_tr("Temizle")?></button>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="basicinput"><?=px_tr("Youtube Güncelleme")?></label>
						<div class="controls">
							<button type="submit" class="btn btn-mini btn-info" name="update_youtube" value="update_youtube"><?=px_tr("Güncelle")?></button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!--/.module-->
	</div>
	<!--/.content-->
</div>
<!--/.span9-->