<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
ob_start();
session_start(); 
?>
<?php include("../inc/setting.php"); ?>
<?php include("./functions.php"); ?>
<?php //if($ooO0000oOo0[0]!=$oo00000oOo0[1]) exit("_"); ?>
<?php 
if($ayar["url"]=="")
{
	$site = 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
	$site = explode("admin/",$site);
	if(isset($_GET["page"]) and $_GET["page"]=="install"){
		update_option("url",$site[0]);
		go_redirect($site[0]."admin/login.html");
	}else{
		go_redirect($site[0]."admin/install.html");
	}
}
?>
<?php 
if(!get_login_status())
{
	include("./inc/login.php");
	exit;
}
?>
<?php include("./header.php"); ?>
<?php 
if(isset($_GET["page"]) and !empty($_GET["page"]))
{
	if($_GET["page"]=="index")
		include("./inc/home.php");
	else
	{
		if(file_exists("./inc/".$_GET["page"].".php"))
			include("./inc/".$_GET["page"].".php");
		else 
			include("./inc/home.php");
	}	
}
else
{
	include("./inc/home.php");
}
?>
<?php include("./footer.php"); ?>
<?php ob_end_flush(); ?>