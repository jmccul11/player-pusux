<?php 
/*b78060ea9121f5151d27d9cf8fdc7b0f*/
//@header('Content-Type: text/plain');
header('Content-type: text/plain; charset=utf-8');
if(@$_GET['ay'] and !empty($_GET['ay']))
{
	$ay = urldecode($_GET['ay']);
	if(!preg_match('@http://|https://|HTTP://|HTTPS://@si',$ay))
		$ay = "http://".$ay;

	$data = get_page($ay);
	echo $data;
}
function get_page($link)
{
	if (function_exists('curl_init')){
		$useragent =  'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36';
		$c = curl_init();
		curl_setopt($c, CURLOPT_BINARYTRANSFER, 1);
		curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($c, CURLOPT_URL, $link);
		curl_setopt($c, CURLOPT_AUTOREFERER, 1);
		curl_setopt($c, CURLOPT_REFERER, $link);
		curl_setopt($c, CURLOPT_TIMEOUT, 20);
		curl_setopt($c, CURLOPT_USERAGENT, $useragent);
		curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
		if(preg_match('@https://@si',$link))
		{
			curl_setopt($c, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
		}
		$exec = curl_exec($c);
		
		$data = utf8_encode($exec);
		if(preg_match('@Ä|Ã@si',$data)) return $exec;

		$data = preg_replace('@Ý@si','İ',$data);
		$data = preg_replace('@ý@si','ı',$data);
		$data = preg_replace('@Ð@si','Ğ',$data);
		$data = preg_replace('@ð@si','ğ',$data);
		$data = preg_replace('@Þ@si','Ş',$data);
		$data = preg_replace('@þ@si','ş',$data);

		return $data;
	}else{
		return file_get_contents($link);
	}
}
function tr_to_utf($text) {   
    $text = trim($text);    
    $search = array('Ü','Ş','Ğ','Ç','İ','Ö','ü','ş','ğ','ç','ı','ö');  
    $replace = array('Ã?','Å','&#286;','Ã?','Ä°','Ã?','Ã¼','Å?','Ä?','Ã§','Ä±','Ã¶');
    $new_text = str_replace($replace,$search,$text);    
    return $new_text;  
}
?>